import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Play,
  CheckCircle2,
  AlertCircle,
  Filter,
  Check,
  X,
  Loader2,
  Sparkles,
  BrainCircuit,
  Clock,
  UserCheck,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { anomaliesAPI } from '../services/api';

export const AnomalyDetectionPage = () => {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [runningDetection, setRunningDetection] = useState(false);

  // Filters
  const [resolvedFilter, setResolvedFilter] = useState('unresolved'); // 'all', 'unresolved', 'resolved'
  const [severityFilter, setSeverityFilter] = useState('ALL');

  // Resolve Modal
  const [isResolveOpen, setIsResolveOpen] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [modalLoading, setModalLoading] = useState(false);

  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const fetchAlerts = async () => {
    try {
      setLoading(true);
      const params = {};
      if (resolvedFilter === 'unresolved') params.is_resolved = false;
      if (resolvedFilter === 'resolved') params.is_resolved = true;
      if (severityFilter && severityFilter !== 'ALL') params.severity = severityFilter;

      const res = await anomaliesAPI.getAll(params);
      setAlerts(res.data);
    } catch (err) {
      console.error(err);
      showToast('Failed to load anomaly alerts', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
  }, [resolvedFilter, severityFilter]);

  const handleRunDetection = async () => {
    setRunningDetection(true);
    try {
      const res = await anomaliesAPI.triggerDetect();
      const count = res.data.alerts_generated_count;
      showToast(
        count > 0
          ? `Analysis finished! Identified ${count} new unusual pattern(s).`
          : 'Analysis complete. No new attendance anomalies identified.'
      );
      fetchAlerts();
    } catch (err) {
      showToast('Failed to run anomaly detection', 'error');
    } finally {
      setRunningDetection(false);
    }
  };

  const handleOpenResolve = (alert) => {
    setSelectedAlert(alert);
    setResolutionNotes('');
    setIsResolveOpen(true);
  };

  const handleResolveSubmit = async (e) => {
    e.preventDefault();
    if (!resolutionNotes.trim()) {
      alert('Please enter resolution notes describing management action taken.');
      return;
    }

    setModalLoading(true);
    try {
      await anomaliesAPI.resolve(selectedAlert.alert_id, {
        resolution_notes: resolutionNotes,
      });
      showToast('Alert resolved and marked in audit trail!');
      setIsResolveOpen(false);
      fetchAlerts();
    } catch (err) {
      showToast('Failed to resolve alert', 'error');
    } finally {
      setModalLoading(false);
    }
  };

  const unresolvedCount = alerts.filter((a) => !a.is_resolved).length;

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toast && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-sm font-semibold transition-all ${
            toast.type === 'error' ? 'bg-rose-600 text-white' : 'bg-emerald-600 text-white'
          }`}
        >
          {toast.type === 'error' ? <AlertCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Header with ML Trigger Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Unusual Attendance Patterns</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-50 text-purple-700 border border-purple-200 flex items-center gap-1">
              <BrainCircuit className="w-3.5 h-3.5" />
              Python ML & Statistics
            </span>
          </div>
          <p className="text-sm text-slate-500 mt-0.5">
            Statistical Z-Score analysis, standard deviation volatility, and Isolation Forest anomaly flags.
          </p>
        </div>

        <button
          onClick={handleRunDetection}
          disabled={runningDetection}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50 text-white text-sm font-bold rounded-xl shadow-lg shadow-purple-600/20 transition-all cursor-pointer self-start sm:self-auto"
        >
          {runningDetection ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Analyzing History...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-white" />
              <span>Run Detection Now</span>
            </>
          )}
        </button>
      </div>

      {/* Methodology Info Banner */}
      <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-indigo-100 text-indigo-700 shrink-0 mt-0.5">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-indigo-950">Explainable Anomaly Identification Engine</h3>
            <p className="text-xs text-indigo-800/90 mt-0.5 leading-relaxed">
              Analyzes arrival volatility (σ ≥ 45 min), chronic lateness, frequent early checkouts, consecutive absence runs, and shift duration Z-scores. Flagged events serve as indicators for human review.
            </p>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          {[
            { id: 'unresolved', label: 'Unresolved Only' },
            { id: 'all', label: 'All Alerts' },
            { id: 'resolved', label: 'Resolved History' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setResolvedFilter(tab.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                resolvedFilter === tab.id
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-500">Severity:</label>
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-blue-600"
          >
            <option value="ALL">All Severities</option>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>
      </div>

      {/* Alerts Cards List */}
      <div className="space-y-3">
        {loading ? (
          <div className="py-16 text-center text-slate-400">
            <Loader2 className="w-8 h-8 animate-spin mx-auto text-purple-600 mb-2" />
            <p className="text-sm font-medium">Scanning attendance records...</p>
          </div>
        ) : alerts.length === 0 ? (
          <div className="p-12 text-center text-slate-400 bg-white rounded-2xl border border-dashed border-slate-200">
            <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-500 mb-2" />
            <p className="text-base font-bold text-slate-800">No Anomaly Alerts Found</p>
            <p className="text-xs text-slate-500 mt-1">
              Either no abnormal patterns match your filter, or all flagged events have been resolved.
            </p>
          </div>
        ) : (
          alerts.map((alert) => (
            <div
              key={alert.alert_id}
              className={`bg-white rounded-2xl border p-5 shadow-sm transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                alert.is_resolved
                  ? 'border-slate-200 bg-slate-50/60 opacity-70'
                  : alert.severity === 'Critical' || alert.severity === 'High'
                  ? 'border-rose-200 hover:border-rose-300'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start gap-4">
                <div
                  className={`p-3 rounded-xl shrink-0 mt-1 ${
                    alert.severity === 'Critical' || alert.severity === 'High'
                      ? 'bg-rose-100 text-rose-700'
                      : alert.severity === 'Medium'
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-blue-100 text-blue-700'
                  }`}
                >
                  <AlertTriangle className="w-5 h-5" />
                </div>

                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="font-bold text-slate-900 text-base">
                      {alert.employee_name}
                    </span>
                    <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                      {alert.employee_code}
                    </span>
                    <span className="text-xs font-medium text-slate-500">• {alert.department_name}</span>

                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                        alert.severity === 'Critical' || alert.severity === 'High'
                          ? 'bg-rose-100 text-rose-700 border border-rose-200'
                          : alert.severity === 'Medium'
                          ? 'bg-amber-100 text-amber-700 border border-amber-200'
                          : 'bg-blue-100 text-blue-700 border border-blue-200'
                      }`}
                    >
                      {alert.severity} Severity
                    </span>

                    <span className="text-[10px] font-mono font-semibold bg-slate-100 px-2 py-0.5 rounded text-slate-700 border border-slate-200">
                      {alert.alert_type}
                    </span>
                  </div>

                  <p className="text-xs text-slate-700 leading-relaxed max-w-3xl">
                    {alert.description}
                  </p>

                  <div className="flex items-center gap-4 mt-2 text-[11px] text-slate-400 font-mono">
                    <span>Detected: {new Date(alert.detected_at).toLocaleString()}</span>
                    {alert.is_resolved && (
                      <span className="text-emerald-600 font-semibold font-sans">
                        ✓ Resolved on {new Date(alert.resolved_at).toLocaleDateString()}
                      </span>
                    )}
                  </div>

                  {alert.resolution_notes && (
                    <div className="mt-2 p-2.5 rounded-xl bg-slate-100 text-slate-600 text-xs font-sans">
                      <strong>Resolution:</strong> {alert.resolution_notes}
                    </div>
                  )}
                </div>
              </div>

              {!alert.is_resolved ? (
                <button
                  onClick={() => handleOpenResolve(alert)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-sm transition-all cursor-pointer shrink-0 self-end md:self-center"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Resolve Alert</span>
                </button>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-xl border border-emerald-200 shrink-0 self-end md:self-center">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Resolved
                </span>
              )}
            </div>
          ))
        )}
      </div>

      {/* RESOLVE MODAL */}
      {isResolveOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
            <button
              onClick={() => setIsResolveOpen(false)}
              className="absolute top-6 right-6 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-slate-900 mb-1">Resolve Attendance Alert</h2>
            <p className="text-xs text-slate-500 mb-4">
              Recording management review notes for {selectedAlert?.employee_name} ({selectedAlert?.alert_type})
            </p>

            <form onSubmit={handleResolveSubmit} className="space-y-4">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700">
                {selectedAlert?.description}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Resolution Notes & Human Review Findings *
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder="e.g., Met with employee. Delay caused by bridge road construction. Shift temporarily adjusted."
                  value={resolutionNotes}
                  onChange={(e) => setResolutionNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsResolveOpen(false)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={modalLoading}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-emerald-600/20 disabled:bg-emerald-400 flex items-center gap-2 cursor-pointer"
                >
                  {modalLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                  <span>Mark as Resolved</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
