import React, { useState, useEffect } from 'react';
import {
  Clock,
  Plus,
  Edit2,
  Trash2,
  UserCheck,
  Calendar,
  X,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Moon,
  Sun,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { shiftsAPI, employeesAPI } from '../services/api';

export const ShiftManagement = () => {
  const [shifts, setShifts] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [loading, setLoading] = useState(true);

  // Modals
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isAssignOpen, setIsAssignOpen] = useState(false);
  const [selectedShift, setSelectedShift] = useState(null);
  const [modalLoading, setModalLoading] = useState(false);

  // Form states
  const initialShiftForm = {
    shift_name: '',
    start_time: '09:00',
    end_time: '17:00',
    grace_period_minutes: 15,
    description: '',
    is_active: true,
    is_overnight: false,
  };
  const [shiftForm, setShiftForm] = useState(initialShiftForm);

  const initialAssignForm = {
    employee_id: '',
    shift_id: '',
    effective_from: new Date().toISOString().split('T')[0],
    effective_to: '',
  };
  const [assignForm, setAssignForm] = useState(initialAssignForm);

  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const fetchData = async () => {
    try {
      setLoading(true);
      const [shiftsRes, empRes, assignRes] = await Promise.all([
        shiftsAPI.getAll(),
        employeesAPI.getAll(),
        shiftsAPI.getAssignments(),
      ]);
      setShifts(shiftsRes.data);
      setEmployees(empRes.data);
      setAssignments(assignRes.data);
      if (empRes.data.length > 0 && !assignForm.employee_id) {
        setAssignForm((prev) => ({ ...prev, employee_id: empRes.data[0].employee_id }));
      }
      if (shiftsRes.data.length > 0 && !assignForm.shift_id) {
        setAssignForm((prev) => ({ ...prev, shift_id: shiftsRes.data[0].shift_id }));
      }
    } catch (err) {
      console.error(err);
      showToast('Failed to load shifts', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenCreate = () => {
    setShiftForm(initialShiftForm);
    setIsCreateOpen(true);
  };

  const handleOpenEdit = (shift) => {
    setSelectedShift(shift);
    setShiftForm({
      shift_name: shift.shift_name,
      start_time: shift.start_time.slice(0, 5),
      end_time: shift.end_time.slice(0, 5),
      grace_period_minutes: shift.grace_period_minutes,
      description: shift.description || '',
      is_active: shift.is_active,
      is_overnight: shift.is_overnight,
    });
    setIsEditOpen(true);
  };

  const handleOpenAssign = (shift = null) => {
    setAssignForm({
      employee_id: employees[0]?.employee_id || '',
      shift_id: shift ? shift.shift_id : (shifts[0]?.shift_id || ''),
      effective_from: new Date().toISOString().split('T')[0],
      effective_to: '',
    });
    setIsAssignOpen(true);
  };

  const handleCreateSubmit = async (e) => {
    e.preventDefault();
    setModalLoading(true);
    try {
      const payload = {
        ...shiftForm,
        start_time: `${shiftForm.start_time}:00`,
        end_time: `${shiftForm.end_time}:00`,
      };
      await shiftsAPI.create(payload);
      showToast('Shift created successfully!');
      setIsCreateOpen(false);
      fetchData();
    } catch (err) {
      showToast(err.response?.data?.detail || 'Failed to create shift', 'error');
    } finally {
      setModalLoading(false);
    }
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    setModalLoading(true);
    try {
      const payload = {
        ...shiftForm,
        start_time: `${shiftForm.start_time}:00`,
        end_time: `${shiftForm.end_time}:00`,
      };
      await shiftsAPI.update(selectedShift.shift_id, payload);
      showToast('Shift updated successfully!');
      setIsEditOpen(false);
      fetchData();
    } catch (err) {
      showToast(err.response?.data?.detail || 'Failed to update shift', 'error');
    } finally {
      setModalLoading(false);
    }
  };

  const handleAssignSubmit = async (e) => {
    e.preventDefault();
    setModalLoading(true);
    try {
      await shiftsAPI.assignShift({
        employee_id: Number(assignForm.employee_id),
        shift_id: Number(assignForm.shift_id),
        effective_from: assignForm.effective_from,
        effective_to: assignForm.effective_to || null,
      });
      showToast('Shift assigned to employee successfully!');
      setIsAssignOpen(false);
      fetchData();
    } catch (err) {
      showToast(err.response?.data?.detail || 'Failed to assign shift', 'error');
    } finally {
      setModalLoading(false);
    }
  };

  const handleDelete = async (shift) => {
    if (window.confirm(`Are you sure you want to deactivate / delete "${shift.shift_name}"?`)) {
      try {
        const res = await shiftsAPI.delete(shift.shift_id);
        showToast(res.data.message || 'Shift deleted/deactivated.');
        fetchData();
      } catch (err) {
        showToast('Failed to delete shift', 'error');
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toast && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-sm font-semibold transition-all ${
            toast.type === 'error' ? 'bg-rose-600 text-white' : 'bg-emerald-600 text-white'
          }`}
        >
          {toast.type === 'error' ? <AlertCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Shift Management</h1>
          <p className="text-sm text-slate-500">
            Define work hours, configure grace periods, support overnight operations, and assign shifts.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto">
          <button
            onClick={() => handleOpenAssign()}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-sm font-semibold rounded-xl shadow-sm transition-all cursor-pointer"
          >
            <UserCheck className="w-4 h-4 text-blue-600" />
            <span>Assign Shift</span>
          </button>
          <button
            onClick={handleOpenCreate}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Shift</span>
          </button>
        </div>
      </div>

      {/* Shifts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {loading ? (
          <div className="col-span-full py-16 text-center text-slate-400">
            <Loader2 className="w-8 h-8 animate-spin mx-auto text-blue-600 mb-2" />
            <p className="text-sm font-medium">Loading shift schedules...</p>
          </div>
        ) : (
          shifts.map((shift) => (
            <div
              key={shift.shift_id}
              className={`bg-white rounded-2xl border p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between ${
                shift.is_active ? 'border-slate-200/80' : 'border-slate-200 opacity-60 bg-slate-50'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${
                        shift.is_overnight
                          ? 'bg-indigo-50 text-indigo-600'
                          : 'bg-amber-50 text-amber-600'
                      }`}
                    >
                      {shift.is_overnight ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-base">{shift.shift_name}</h3>
                      <p className="text-[11px] text-slate-400 font-mono">Shift ID: #{shift.shift_id}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(shift)}
                      className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                      title="Edit Shift"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(shift)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Deactivate Shift"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Timing Badge */}
                <div className="my-3 p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                      Work Hours
                    </span>
                    <span className="text-sm font-bold font-mono text-slate-800">
                      {shift.start_time.slice(0, 5)} - {shift.end_time.slice(0, 5)}
                    </span>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                      Grace Period
                    </span>
                    <span className="text-xs font-semibold text-emerald-600">
                      +{shift.grace_period_minutes} min
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed min-h-[2.5rem]">
                  {shift.description || 'Standard corporate working shift.'}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  {shift.is_overnight && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                      Overnight
                    </span>
                  )}
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      shift.is_active
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {shift.is_active ? 'Active' : 'Inactive'}
                  </span>
                </div>

                <button
                  onClick={() => handleOpenAssign(shift)}
                  className="font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
                >
                  Assign to Staff <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Shift Assignments Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">Recent Shift Assignment History</h2>
            <p className="text-xs text-slate-500">Scheduled shift periods for personnel</p>
          </div>
          <button
            onClick={() => handleOpenAssign()}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
          >
            + New Assignment
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-5 py-3">Employee</th>
                <th className="px-5 py-3">Assigned Shift</th>
                <th className="px-5 py-3">Effective Range</th>
                <th className="px-5 py-3">Timing</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {assignments.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-5 py-8 text-center text-slate-400">
                    No explicit shift assignments recorded.
                  </td>
                </tr>
              ) : (
                assignments.map((a) => {
                  const emp = employees.find((e) => e.employee_id === a.employee_id);
                  return (
                    <tr key={a.assignment_id} className="hover:bg-slate-50/60">
                      <td className="px-5 py-3 font-medium text-slate-900">
                        {emp ? `${emp.first_name} ${emp.last_name} (${emp.employee_code})` : `Employee #${a.employee_id}`}
                      </td>
                      <td className="px-5 py-3 font-semibold text-blue-700">{a.shift_name}</td>
                      <td className="px-5 py-3 text-slate-600 font-mono">
                        {a.effective_from} → {a.effective_to || 'Ongoing'}
                      </td>
                      <td className="px-5 py-3 text-slate-700 font-mono">
                        {a.start_time?.slice(0, 5)} - {a.end_time?.slice(0, 5)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE SHIFT MODAL */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
            <button
              onClick={() => setIsCreateOpen(false)}
              className="absolute top-6 right-6 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-slate-900 mb-1">Create Shift</h2>
            <p className="text-xs text-slate-500 mb-5">Configure a new standard or overnight shift.</p>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Shift Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Early Bird Shift, European Support Shift"
                  value={shiftForm.shift_name}
                  onChange={(e) => setShiftForm({ ...shiftForm, shift_name: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Start Time *</label>
                  <input
                    type="time"
                    required
                    value={shiftForm.start_time}
                    onChange={(e) => setShiftForm({ ...shiftForm, start_time: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">End Time *</label>
                  <input
                    type="time"
                    required
                    value={shiftForm.end_time}
                    onChange={(e) => setShiftForm({ ...shiftForm, end_time: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Grace Period (Minutes)</label>
                  <input
                    type="number"
                    min="0"
                    max="120"
                    value={shiftForm.grace_period_minutes}
                    onChange={(e) => setShiftForm({ ...shiftForm, grace_period_minutes: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono"
                  />
                </div>

                <div className="flex flex-col justify-end pb-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={shiftForm.is_overnight}
                      onChange={(e) => setShiftForm({ ...shiftForm, is_overnight: e.target.checked })}
                      className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-xs font-semibold text-slate-700">Overnight Shift (Ends next day)</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="Notes about shift operational responsibilities..."
                  value={shiftForm.description}
                  onChange={(e) => setShiftForm({ ...shiftForm, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={modalLoading}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-blue-600/20 disabled:bg-blue-400 flex items-center gap-2 cursor-pointer"
                >
                  {modalLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                  <span>Save Shift</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT SHIFT MODAL */}
      {isEditOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
            <button
              onClick={() => setIsEditOpen(false)}
              className="absolute top-6 right-6 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-slate-900 mb-1">Edit Shift</h2>
            <p className="text-xs text-slate-500 mb-5">Updating {selectedShift?.shift_name}</p>

            <form onSubmit={handleEditSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Shift Name *</label>
                <input
                  type="text"
                  required
                  value={shiftForm.shift_name}
                  onChange={(e) => setShiftForm({ ...shiftForm, shift_name: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Start Time *</label>
                  <input
                    type="time"
                    required
                    value={shiftForm.start_time}
                    onChange={(e) => setShiftForm({ ...shiftForm, start_time: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">End Time *</label>
                  <input
                    type="time"
                    required
                    value={shiftForm.end_time}
                    onChange={(e) => setShiftForm({ ...shiftForm, end_time: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Grace Period (Minutes)</label>
                  <input
                    type="number"
                    min="0"
                    max="120"
                    value={shiftForm.grace_period_minutes}
                    onChange={(e) => setShiftForm({ ...shiftForm, grace_period_minutes: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono"
                  />
                </div>

                <div className="flex flex-col justify-end pb-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={shiftForm.is_overnight}
                      onChange={(e) => setShiftForm({ ...shiftForm, is_overnight: e.target.checked })}
                      className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                    />
                    <span className="text-xs font-semibold text-slate-700">Overnight Shift</span>
                  </label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditOpen(false)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={modalLoading}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-blue-600/20 disabled:bg-blue-400 flex items-center gap-2 cursor-pointer"
                >
                  {modalLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                  <span>Save Changes</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ASSIGN SHIFT MODAL */}
      {isAssignOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
            <button
              onClick={() => setIsAssignOpen(false)}
              className="absolute top-6 right-6 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-slate-900 mb-1">Assign Shift to Employee</h2>
            <p className="text-xs text-slate-500 mb-5">Designates working schedule and grace policy for staff.</p>

            <form onSubmit={handleAssignSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Select Employee *</label>
                <select
                  required
                  value={assignForm.employee_id}
                  onChange={(e) => setAssignForm({ ...assignForm, employee_id: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium"
                >
                  {employees.map((e) => (
                    <option key={e.employee_id} value={e.employee_id}>
                      {e.first_name} {e.last_name} ({e.employee_code} - {e.department_name})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Select Shift *</label>
                <select
                  required
                  value={assignForm.shift_id}
                  onChange={(e) => setAssignForm({ ...assignForm, shift_id: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium"
                >
                  {shifts.map((s) => (
                    <option key={s.shift_id} value={s.shift_id}>
                      {s.shift_name} ({s.start_time.slice(0, 5)} - {s.end_time.slice(0, 5)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Effective From *</label>
                  <input
                    type="date"
                    required
                    value={assignForm.effective_from}
                    onChange={(e) => setAssignForm({ ...assignForm, effective_from: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Effective To (Optional)</label>
                  <input
                    type="date"
                    value={assignForm.effective_to}
                    onChange={(e) => setAssignForm({ ...assignForm, effective_to: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAssignOpen(false)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={modalLoading}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-blue-600/20 disabled:bg-blue-400 flex items-center gap-2 cursor-pointer"
                >
                  {modalLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                  <span>Save Assignment</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
