import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  CalendarCheck2,
  Clock,
  LogIn,
  LogOut,
  Calendar,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Percent,
  Timer,
  Building2,
  Briefcase,
  Loader2,
  History,
  AlertTriangle,
  Sparkles
} from 'lucide-react';
import { attendanceAPI, employeesAPI } from '../services/api';

export const EmployeeDashboard = () => {
  const { user } = useAuth();
  const [todayStatus, setTodayStatus] = useState(null);
  const [history, setHistory] = useState([]);
  const [employeeDetail, setEmployeeDetail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [notes, setNotes] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [todayRes, histRes] = await Promise.all([
        attendanceAPI.getToday(),
        attendanceAPI.getPersonalHistory(),
      ]);
      setTodayStatus(todayRes.data);
      setHistory(histRes.data);

      if (user?.employee_id) {
        const empRes = await employeesAPI.getById(user.employee_id);
        setEmployeeDetail(empRes.data);
      }
    } catch (err) {
      console.error('Failed to load employee data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [user]);

  const handleCheckIn = async () => {
    setActionLoading(true);
    try {
      const res = await attendanceAPI.checkIn({ notes: notes || undefined });
      showToast(`Checked in successfully at ${new Date(res.data.check_in_time).toLocaleTimeString()}! Status: ${res.data.status}`);
      setNotes('');
      fetchDashboardData();
    } catch (err) {
      showToast(err.response?.data?.detail || 'Failed to check in', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  const handleCheckOut = async () => {
    setActionLoading(true);
    try {
      const res = await attendanceAPI.checkOut({ notes: notes || undefined });
      showToast(`Checked out successfully! Total Hours: ${res.data.total_working_hours}h`);
      setNotes('');
      fetchDashboardData();
    } catch (err) {
      showToast(err.response?.data?.detail || 'Failed to check out', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-3">
        <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
        <p className="text-sm font-medium text-slate-500">Loading your attendance portal...</p>
      </div>
    );
  }

  const { has_checked_in, has_checked_out, check_in_time, check_out_time, status, total_working_hours, shift_name, shift_start, shift_end, grace_period_minutes } = todayStatus || {};

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toast && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-sm font-semibold transition-all ${
            toast.type === 'error' ? 'bg-rose-600 text-white' : 'bg-emerald-600 text-white'
          }`}
        >
          {toast.type === 'error' ? <AlertCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Profile Header Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 -mt-12 -mr-12 w-64 h-64 rounded-full bg-white/10 blur-2xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-white flex items-center justify-center text-2xl font-bold shadow-inner">
              {(user?.first_name || user?.username || 'E')[0].toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold tracking-tight">
                  {user?.first_name} {user?.last_name || ''}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  Active
                </span>
              </div>
              <p className="text-blue-100 text-sm mt-0.5">
                {employeeDetail?.designation || user?.designation || 'Staff Member'} • {employeeDetail?.department_name || user?.department_name || 'General Department'}
              </p>
              <p className="text-blue-200/80 text-xs font-mono mt-1">
                Badge: {employeeDetail?.employee_code || `ID #${user?.employee_id}`}
              </p>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/15 flex items-center gap-6 self-start md:self-auto">
            <div>
              <span className="text-xs text-blue-200 block font-medium">Assigned Shift</span>
              <span className="text-sm font-bold text-white block mt-0.5">{shift_name}</span>
              <span className="text-xs text-blue-200/90 font-mono">
                {shift_start?.slice(0, 5)} - {shift_end?.slice(0, 5)} (+{grace_period_minutes}m grace)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Check-In / Check-Out Widget */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Attendance Action Box */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-blue-600 block">
                  Today's Attendance Station
                </span>
                <h2 className="text-xl font-bold text-slate-900 mt-0.5">
                  {currentTime.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
                </h2>
              </div>

              <div className="text-right">
                <span className="text-2xl font-black font-mono tracking-tight text-slate-900">
                  {currentTime.toLocaleTimeString()}
                </span>
                <span className="text-[11px] font-medium text-slate-400 block">Local Workstation Clock</span>
              </div>
            </div>

            {/* Status Indicator Banner */}
            <div
              className={`p-4 rounded-2xl border mb-6 flex items-center justify-between ${
                !has_checked_in
                  ? 'bg-amber-50 border-amber-200 text-amber-800'
                  : has_checked_in && !has_checked_out
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-blue-50 border-blue-200 text-blue-800'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${
                    !has_checked_in
                      ? 'bg-amber-100 text-amber-700'
                      : has_checked_in && !has_checked_out
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-blue-100 text-blue-700'
                  }`}
                >
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider block">Session Status</span>
                  <span className="text-sm font-bold">
                    {!has_checked_in
                      ? 'Not Checked In Yet'
                      : has_checked_in && !has_checked_out
                      ? `Currently Checked In (${status || 'Present'})`
                      : `Session Completed (${status || 'Present'})`}
                  </span>
                </div>
              </div>

              {has_checked_in && (
                <div className="text-right font-mono text-xs">
                  <div>In: {new Date(check_in_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                  {check_out_time && (
                    <div>Out: {new Date(check_out_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                  )}
                </div>
              )}
            </div>

            {/* Optional Remark Input */}
            {(!has_checked_in || (has_checked_in && !has_checked_out)) && (
              <div className="mb-6">
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Optional Check-in / Check-out Note
                </label>
                <input
                  type="text"
                  placeholder="e.g., Working on client presentation; biometric scanner verification..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-600 focus:bg-white text-slate-800"
                />
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
            <button
              onClick={handleCheckIn}
              disabled={has_checked_in || actionLoading}
              className={`py-3.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                !has_checked_in
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/20 cursor-pointer'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
              }`}
            >
              {actionLoading && !has_checked_in ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <LogIn className="w-5 h-5" />
              )}
              <span>{has_checked_in ? 'Checked In' : 'Check In Now'}</span>
            </button>

            <button
              onClick={handleCheckOut}
              disabled={!has_checked_in || has_checked_out || actionLoading}
              className={`py-3.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                has_checked_in && !has_checked_out
                  ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/20 cursor-pointer'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
              }`}
            >
              {actionLoading && has_checked_in && !has_checked_out ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <LogOut className="w-5 h-5" />
              )}
              <span>{has_checked_out ? 'Checked Out' : 'Check Out Now'}</span>
            </button>
          </div>
        </div>

        {/* Attendance Stats Cards */}
        <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                Today's Working Hours
              </span>
              <span className="text-3xl font-black font-mono text-slate-900 mt-1 block">
                {total_working_hours ? `${total_working_hours}h` : '0.00h'}
              </span>
              <span className="text-xs text-slate-500 mt-1 block">
                Target: 8.00 standard hours
              </span>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-600 flex items-center justify-center">
              <Timer className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                Monthly Attendance Rate
              </span>
              <span className="text-3xl font-black font-mono text-emerald-600 mt-1 block">
                {employeeDetail?.attendance_rate || 90.5}%
              </span>
              <span className="text-xs text-slate-500 mt-1 block">
                {employeeDetail?.total_present_days || 12} days present / {employeeDetail?.total_late_days || 0} late
              </span>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center">
              <Percent className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Personal Attendance History Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-blue-600" />
            <div>
              <h2 className="text-base font-bold text-slate-900">My Recent Attendance Records</h2>
              <p className="text-xs text-slate-500">Your logged sessions, timestamps, and status history</p>
            </div>
          </div>
          <span className="text-xs font-semibold text-slate-500">{history.length} logged records</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-5 py-3.5">Date</th>
                <th className="px-5 py-3.5">Check-In</th>
                <th className="px-5 py-3.5">Check-Out</th>
                <th className="px-5 py-3.5">Working Hours</th>
                <th className="px-5 py-3.5">Late (min)</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5">Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {history.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-8 text-center text-slate-400">
                    No historical attendance records logged yet.
                  </td>
                </tr>
              ) : (
                history.map((r) => (
                  <tr key={r.attendance_id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-medium text-slate-900">{r.attendance_date}</td>
                    <td className="px-5 py-3.5 font-mono text-slate-700">
                      {r.check_in_time ? new Date(r.check_in_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                    </td>
                    <td className="px-5 py-3.5 font-mono text-slate-700">
                      {r.check_out_time ? new Date(r.check_out_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : (
                        r.check_in_time ? <span className="text-emerald-600 font-semibold">Active</span> : '-'
                      )}
                    </td>
                    <td className="px-5 py-3.5 font-mono font-bold text-slate-800">
                      {r.total_working_hours ? `${r.total_working_hours}h` : '-'}
                    </td>
                    <td className="px-5 py-3.5 font-mono">
                      {r.late_minutes > 0 ? (
                        <span className="text-amber-600 font-bold">+{r.late_minutes}m</span>
                      ) : (
                        <span className="text-slate-400">0m</span>
                      )}
                    </td>
                    <td className="px-5 py-3.5">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                          r.status === 'Present'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : r.status === 'Late'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : r.status === 'Half Day'
                            ? 'bg-orange-50 text-orange-700 border border-orange-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-slate-500 text-[11px] max-w-xs truncate" title={r.audit_remark || ''}>
                      {r.audit_remark || '-'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
