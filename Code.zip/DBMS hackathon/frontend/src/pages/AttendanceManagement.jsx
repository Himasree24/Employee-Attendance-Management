import React, { useState, useEffect } from 'react';
import {
  CalendarCheck2,
  Search,
  Filter,
  Edit3,
  Calendar,
  Clock,
  Building2,
  AlertCircle,
  CheckCircle2,
  X,
  Loader2,
  ShieldAlert,
  ArrowUpDown
} from 'lucide-react';
import { attendanceAPI, employeesAPI, departmentsAPI } from '../services/api';

export const AttendanceManagement = () => {
  const [records, setRecords] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [selectedDate, setSelectedDate] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedEmp, setSelectedEmp] = useState('');
  const [selectedDept, setSelectedDept] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('ALL');

  // Manual Correction Modal
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [editStatus, setEditStatus] = useState('Present');
  const [editCheckIn, setEditCheckIn] = useState('');
  const [editCheckOut, setEditCheckOut] = useState('');
  const [auditRemark, setAuditRemark] = useState('');
  const [modalLoading, setModalLoading] = useState(false);

  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const fetchDependencies = async () => {
    try {
      const [empRes, deptRes] = await Promise.all([
        employeesAPI.getAll(),
        departmentsAPI.getAll(),
      ]);
      setEmployees(empRes.data);
      setDepartments(deptRes.data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchAttendance = async () => {
    try {
      setLoading(true);
      const params = {};
      if (selectedDate) {
        params.target_date = selectedDate;
      } else {
        if (startDate) params.start_date = startDate;
        if (endDate) params.end_date = endDate;
      }
      if (selectedEmp) params.employee_id = selectedEmp;
      if (selectedDept) params.department_id = selectedDept;
      if (selectedStatus && selectedStatus !== 'ALL') params.status = selectedStatus;

      const res = await attendanceAPI.getAll(params);
      setRecords(res.data);
    } catch (err) {
      console.error('Failed to load attendance:', err);
      showToast('Failed to load attendance records', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDependencies();
  }, []);

  useEffect(() => {
    fetchAttendance();
  }, [selectedDate, startDate, endDate, selectedEmp, selectedDept, selectedStatus]);

  const handleOpenEdit = (rec) => {
    setSelectedRecord(rec);
    setEditStatus(rec.status);
    setEditCheckIn(rec.check_in_time ? rec.check_in_time.slice(0, 16) : '');
    setEditCheckOut(rec.check_out_time ? rec.check_out_time.slice(0, 16) : '');
    setAuditRemark('');
    setIsEditOpen(true);
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    if (!auditRemark.trim()) {
      alert('An audit remark explaining the rationale for this manual correction is mandatory.');
      return;
    }

    setModalLoading(true);
    try {
      await attendanceAPI.update(selectedRecord.attendance_id, {
        status: editStatus,
        check_in_time: editCheckIn ? new Date(editCheckIn).toISOString() : null,
        check_out_time: editCheckOut ? new Date(editCheckOut).toISOString() : null,
        audit_remark: auditRemark,
      });
      showToast('Attendance corrected with audit log trail!');
      setIsEditOpen(false);
      fetchAttendance();
    } catch (err) {
      showToast(err.response?.data?.detail || 'Failed to update attendance', 'error');
    } finally {
      setModalLoading(false);
    }
  };

  const clearFilters = () => {
    setSelectedDate('');
    setStartDate('');
    setEndDate('');
    setSelectedEmp('');
    setSelectedDept('');
    setSelectedStatus('ALL');
  };

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toast && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-sm font-semibold transition-all ${
            toast.type === 'error' ? 'bg-rose-600 text-white' : 'bg-emerald-600 text-white'
          }`}
        >
          {toast.type === 'error' ? <AlertCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Master Attendance Log</h1>
          <p className="text-sm text-slate-500">
            View, audit, and manually correct daily check-in and check-out logs across all departments.
          </p>
        </div>

        <button
          onClick={clearFilters}
          className="text-xs font-semibold text-slate-600 hover:text-blue-600 bg-white border border-slate-200 px-3 py-1.5 rounded-xl shadow-sm self-start sm:self-auto cursor-pointer"
        >
          Reset All Filters
        </button>
      </div>

      {/* Filters Card */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <div>
          <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
            Exact Date
          </label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => {
              setSelectedDate(e.target.value);
              setStartDate('');
              setEndDate('');
            }}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:ring-2 focus:ring-blue-600 focus:bg-white"
          />
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
            Date Range (Start → End)
          </label>
          <div className="grid grid-cols-2 gap-1.5">
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setSelectedDate('');
              }}
              className="w-full px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
            />
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setSelectedDate('');
              }}
              className="w-full px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
            />
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
            Filter Employee
          </label>
          <select
            value={selectedEmp}
            onChange={(e) => setSelectedEmp(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-blue-600 focus:bg-white"
          >
            <option value="">All Employees</option>
            {employees.map((e) => (
              <option key={e.employee_id} value={e.employee_id}>
                {e.first_name} {e.last_name} ({e.employee_code})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
            Filter Department
          </label>
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-blue-600 focus:bg-white"
          >
            <option value="">All Departments</option>
            {departments.map((d) => (
              <option key={d.department_id} value={d.department_id}>
                {d.department_name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
            Status
          </label>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-blue-600 focus:bg-white"
          >
            <option value="ALL">All Statuses</option>
            <option value="Present">Present</option>
            <option value="Late">Late</option>
            <option value="Absent">Absent</option>
            <option value="Half Day">Half Day</option>
            <option value="On Leave">On Leave</option>
          </select>
        </div>
      </div>

      {/* Attendance Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Showing <strong>{records.length}</strong> attendance records</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3.5">Date</th>
                <th className="px-4 py-3.5">Employee</th>
                <th className="px-4 py-3.5">Department</th>
                <th className="px-4 py-3.5">Check-In</th>
                <th className="px-4 py-3.5">Check-Out</th>
                <th className="px-4 py-3.5">Working Hours</th>
                <th className="px-4 py-3.5">Late (min)</th>
                <th className="px-4 py-3.5">Early (min)</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5">Audit Note</th>
                <th className="px-4 py-3.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={11} className="px-4 py-12 text-center text-slate-400">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto text-blue-600 mb-2" />
                    <span>Loading attendance logs...</span>
                  </td>
                </tr>
              ) : records.length === 0 ? (
                <tr>
                  <td colSpan={11} className="px-4 py-12 text-center text-slate-400">
                    No attendance records match the selected parameters.
                  </td>
                </tr>
              ) : (
                records.map((r) => (
                  <tr key={r.attendance_id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-4 py-3.5 font-mono text-slate-900 font-medium whitespace-nowrap">
                      {r.attendance_date}
                    </td>
                    <td className="px-4 py-3.5 whitespace-nowrap">
                      <div className="font-bold text-slate-900">{r.employee_name}</div>
                      <div className="text-[11px] text-slate-400 font-mono">{r.employee_code}</div>
                    </td>
                    <td className="px-4 py-3.5 text-slate-600 whitespace-nowrap">{r.department_name}</td>
                    <td className="px-4 py-3.5 font-mono text-slate-700 whitespace-nowrap">
                      {r.check_in_time ? new Date(r.check_in_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                    </td>
                    <td className="px-4 py-3.5 font-mono text-slate-700 whitespace-nowrap">
                      {r.check_out_time ? (
                        new Date(r.check_out_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                      ) : (
                        r.check_in_time ? <span className="text-emerald-600 font-semibold font-sans">Active</span> : '-'
                      )}
                    </td>
                    <td className="px-4 py-3.5 font-mono text-slate-800 whitespace-nowrap font-medium">
                      {r.total_working_hours ? `${r.total_working_hours}h` : '-'}
                    </td>
                    <td className="px-4 py-3.5 font-mono whitespace-nowrap">
                      {r.late_minutes > 0 ? (
                        <span className="text-amber-600 font-bold">+{r.late_minutes}m</span>
                      ) : (
                        <span className="text-slate-400">0m</span>
                      )}
                    </td>
                    <td className="px-4 py-3.5 font-mono whitespace-nowrap">
                      {r.early_checkout_minutes > 0 ? (
                        <span className="text-orange-600 font-bold">-{r.early_checkout_minutes}m</span>
                      ) : (
                        <span className="text-slate-400">0m</span>
                      )}
                    </td>
                    <td className="px-4 py-3.5 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                          r.status === 'Present'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : r.status === 'Late'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : r.status === 'Half Day'
                            ? 'bg-orange-50 text-orange-700 border border-orange-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-slate-500 text-[11px] max-w-xs truncate" title={r.audit_remark || ''}>
                      {r.audit_remark || '-'}
                    </td>
                    <td className="px-4 py-3.5 text-right whitespace-nowrap">
                      <button
                        onClick={() => handleOpenEdit(r)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-slate-600 hover:text-blue-700 hover:bg-blue-50 border border-slate-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Correct</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MANUAL CORRECTION MODAL */}
      {isEditOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
            <button
              onClick={() => setIsEditOpen(false)}
              className="absolute top-6 right-6 p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-slate-900 mb-1">Manual Attendance Correction</h2>
            <p className="text-xs text-slate-500 mb-4">
              Audit log will document modifications made to {selectedRecord?.employee_name}'s record on {selectedRecord?.attendance_date}.
            </p>

            <form onSubmit={handleEditSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Attendance Status *</label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium"
                >
                  <option value="Present">Present</option>
                  <option value="Late">Late</option>
                  <option value="Half Day">Half Day</option>
                  <option value="Absent">Absent</option>
                  <option value="On Leave">On Leave</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Check-In Timestamp</label>
                  <input
                    type="datetime-local"
                    value={editCheckIn}
                    onChange={(e) => setEditCheckIn(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Check-Out Timestamp</label>
                  <input
                    type="datetime-local"
                    value={editCheckOut}
                    onChange={(e) => setEditCheckOut(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-rose-700 mb-1">
                  Mandatory Audit Remark / Justification *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="e.g., Gate biometric scanner malfunction; verified with building badge entry log."
                  value={auditRemark}
                  onChange={(e) => setAuditRemark(e.target.value)}
                  className="w-full px-3 py-2 bg-rose-50/30 border border-rose-200 rounded-xl text-sm focus:ring-2 focus:ring-rose-500 focus:bg-white"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditOpen(false)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={modalLoading}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-blue-600/20 disabled:bg-blue-400 flex items-center gap-2 cursor-pointer"
                >
                  {modalLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                  <span>Save Correction</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
