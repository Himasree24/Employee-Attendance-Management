import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  CalendarCheck2,
  Lock,
  Mail,
  ArrowRight,
  ShieldAlert,
  Loader2,
  CheckCircle2,
  UserCheck,
  ShieldCheck,
  Sparkles
} from 'lucide-react';

export const LoginPage = () => {
  const [usernameOrEmail, setUsernameOrEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!usernameOrEmail || !password) {
      setError('Please provide both username/email and password.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const userInfo = await login(usernameOrEmail, password);
      if (userInfo.role === 'ADMIN') {
        navigate('/admin/dashboard');
      } else {
        navigate('/employee/dashboard');
      }
    } catch (err) {
      console.error(err);
      setError(
        err.response?.data?.detail ||
        'Authentication failed. Please check your credentials and try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleQuickFill = (email, pwd) => {
    setUsernameOrEmail(email);
    setPassword(pwd);
    setError('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl w-full grid grid-cols-1 lg:grid-cols-12 bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-700/30">
        
        {/* Left Side: Brand Banner */}
        <div className="lg:col-span-5 bg-gradient-to-br from-blue-600 via-indigo-600 to-blue-800 p-8 sm:p-10 text-white flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 rounded-full bg-white/10 blur-2xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-64 h-64 rounded-full bg-indigo-900/30 blur-2xl pointer-events-none" />

          <div>
            <div className="inline-flex items-center gap-2.5 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md border border-white/20 text-xs font-semibold mb-6">
              <Sparkles className="w-3.5 h-3.5 text-blue-200" />
              <span>Full-Stack Attendance System</span>
            </div>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-white text-blue-600 flex items-center justify-center shadow-lg shadow-black/10">
                <CalendarCheck2 className="w-7 h-7" />
              </div>
              <div>
                <h1 className="text-2xl font-bold tracking-tight">AttendDate</h1>
                <p className="text-blue-100 text-xs font-medium">Enterprise Management Suite</p>
              </div>
            </div>

            <p className="text-blue-100/90 text-sm leading-relaxed mt-6">
              Automated employee check-in & check-out, shift scheduling, real-time analytics, and statistical anomaly detection powered by Python & Machine Learning.
            </p>
          </div>

          {/* Feature Highlights */}
          <div className="space-y-3 my-8">
            <div className="flex items-center gap-2.5 text-xs text-blue-100 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
              <span>MySQL Normalized Relational Backend</span>
            </div>
            <div className="flex items-center gap-2.5 text-xs text-blue-100 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
              <span>Overnight Shift & Grace Period Engine</span>
            </div>
            <div className="flex items-center gap-2.5 text-xs text-blue-100 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
              <span>Scikit-Learn & Z-Score Pattern Detection</span>
            </div>
          </div>

          <div className="text-[11px] text-blue-200/80 pt-4 border-t border-white/10">
            Secure Role-Based Access Control • JWT Authenticated
          </div>
        </div>

        {/* Right Side: Login Form */}
        <div className="lg:col-span-7 p-8 sm:p-10 flex flex-col justify-center bg-white">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Account Sign In</h2>
            <p className="text-sm text-slate-500 mt-1">
              Enter your credentials to access your administrative portal or personal attendance console.
            </p>
          </div>

          {error && (
            <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div className="text-sm text-rose-700 leading-snug">{error}</div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
                Username or Work Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={usernameOrEmail}
                  onChange={(e) => setUsernameOrEmail(e.target.value)}
                  placeholder="e.g. admin@company.com or john.doe"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition-all text-slate-900 placeholder:text-slate-400"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition-all text-slate-900 placeholder:text-slate-400"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 px-4 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-semibold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-600/25 transition-all cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <span>Sign In to System</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Quick Fill Test Profiles */}
          <div className="mt-8 pt-6 border-t border-slate-100">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2.5">
              Quick Test Accounts (Click to Fill):
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickFill('admin@company.com', 'Admin@123')}
                className="p-2.5 rounded-lg border border-slate-200 hover:border-blue-400 hover:bg-blue-50/50 text-left transition-all group cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-purple-600" />
                  <span className="text-xs font-bold text-slate-800 group-hover:text-blue-700">Admin Account</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">admin@company.com / Admin@123</p>
              </button>

              <button
                type="button"
                onClick={() => handleQuickFill('john.doe@company.com', 'User@123')}
                className="p-2.5 rounded-lg border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50 text-left transition-all group cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-bold text-slate-800 group-hover:text-emerald-700">Punctual Employee</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">john.doe@company.com / User@123</p>
              </button>

              <button
                type="button"
                onClick={() => handleQuickFill('robert.b@company.com', 'User@123')}
                className="p-2.5 rounded-lg border border-slate-200 hover:border-amber-400 hover:bg-amber-50/50 text-left transition-all group cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-amber-600" />
                  <span className="text-xs font-bold text-slate-800 group-hover:text-amber-700">Chronic Late Emp</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">robert.b@company.com / User@123</p>
              </button>

              <button
                type="button"
                onClick={() => handleQuickFill('emily.d@company.com', 'User@123')}
                className="p-2.5 rounded-lg border border-slate-200 hover:border-rose-400 hover:bg-rose-50/50 text-left transition-all group cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-rose-600" />
                  <span className="text-xs font-bold text-slate-800 group-hover:text-rose-700">Early Departure Emp</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">emily.d@company.com / User@123</p>
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
