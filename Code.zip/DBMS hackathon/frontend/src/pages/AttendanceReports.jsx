import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Download,
  Calendar,
  Filter,
  Users,
  Building2,
  Clock,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Percent,
  Timer,
  FileText
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend
} from 'recharts';
import { reportsAPI, employeesAPI, departmentsAPI } from '../services/api';

export const AttendanceReports = () => {
  const [reportType, setReportType] = useState('daily'); // daily, weekly, monthly, employee, department
  const [loading, setLoading] = useState(true);
  const [reportData, setReportData] = useState(null);

  // Filter params
  const [targetDate, setTargetDate] = useState(new Date().toISOString().split('T')[0]);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedDept, setSelectedDept] = useState('');
  const [selectedEmp, setSelectedEmp] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Lookups
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);

  useEffect(() => {
    Promise.all([employeesAPI.getAll(), departmentsAPI.getAll()]).then(([eRes, dRes]) => {
      setEmployees(eRes.data);
      setDepartments(dRes.data);
      if (eRes.data.length > 0 && !selectedEmp) setSelectedEmp(eRes.data[0].employee_id);
      if (dRes.data.length > 0 && !selectedDept) setSelectedDept(dRes.data[0].department_id);
    });
  }, []);

  const fetchReport = async () => {
    try {
      setLoading(true);
      let res;
      if (reportType === 'daily') {
        res = await reportsAPI.getDaily({
          report_date: targetDate,
          department_id: selectedDept || undefined,
        });
      } else if (reportType === 'weekly') {
        res = await reportsAPI.getWeekly({
          start_date: targetDate,
          department_id: selectedDept || undefined,
        });
      } else if (reportType === 'monthly') {
        const d = new Date(targetDate);
        res = await reportsAPI.getMonthly({
          month: d.getMonth() + 1,
          year: d.getFullYear(),
          department_id: selectedDept || undefined,
        });
      } else if (reportType === 'employee') {
        res = await reportsAPI.getEmployee({
          employee_id: selectedEmp,
          start_date: startDate || undefined,
          end_date: endDate || undefined,
        });
      } else if (reportType === 'department') {
        res = await reportsAPI.getDepartment({
          department_id: selectedDept,
          start_date: startDate || undefined,
          end_date: endDate || undefined,
        });
      }
      setReportData(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReport();
  }, [reportType, targetDate, startDate, endDate, selectedDept, selectedEmp]);

  const handleExportCsv = () => {
    const params = {};
    if (reportType === 'daily') {
      params.start_date = targetDate;
      params.end_date = targetDate;
    } else if (startDate && endDate) {
      params.start_date = startDate;
      params.end_date = endDate;
    }
    if (selectedDept) params.department_id = selectedDept;
    if (selectedEmp && reportType === 'employee') params.employee_id = selectedEmp;
    if (statusFilter && statusFilter !== 'ALL') params.status = statusFilter;

    const url = reportsAPI.downloadCsvUrl(params);
    window.open(url, '_blank');
  };

  const handleExportPdf = () => {
    const params = {};
    if (reportType === 'daily') {
      params.start_date = targetDate;
      params.end_date = targetDate;
    } else if (startDate && endDate) {
      params.start_date = startDate;
      params.end_date = endDate;
    }
    if (selectedDept) params.department_id = selectedDept;
    if (selectedEmp && reportType === 'employee') params.employee_id = selectedEmp;
    if (statusFilter && statusFilter !== 'ALL') params.status = statusFilter;

    const url = reportsAPI.downloadPdfUrl(params);
    window.open(url, '_blank');
  };

  const summary = reportData?.summary;
  const records = reportData?.records || [];

  const chartData = [
    { name: 'Present', count: summary?.present_count || 0, fill: '#22c55e' },
    { name: 'Late', count: summary?.late_count || 0, fill: '#eab308' },
    { name: 'Absent', count: summary?.absent_count || 0, fill: '#ef4444' },
    { name: 'Half Day', count: summary?.half_day_count || 0, fill: '#f97316' },
    { name: 'On Leave', count: summary?.on_leave_count || 0, fill: '#3b82f6' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Attendance Reports & Exports</h1>
          <p className="text-sm text-slate-500">
            Generate formal daily, weekly, monthly, and departmental attendance summaries with CSV & PDF export.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleExportCsv}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl shadow-sm transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-600" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleExportPdf}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>Export PDF</span>
          </button>
        </div>
      </div>

      {/* Report Tabs */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200/80 shadow-sm flex items-center gap-1 overflow-x-auto">
        {[
          { id: 'daily', label: 'Daily Report' },
          { id: 'weekly', label: 'Weekly Report' },
          { id: 'monthly', label: 'Monthly Report' },
          { id: 'employee', label: 'Employee-Wise Report' },
          { id: 'department', label: 'Department-Wise Report' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setReportType(tab.id)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
              reportType === tab.id
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Dynamic Filters Row */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {reportType === 'daily' && (
          <div>
            <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Select Date
            </label>
            <input
              type="date"
              value={targetDate}
              onChange={(e) => setTargetDate(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
            />
          </div>
        )}

        {(reportType === 'weekly' || reportType === 'monthly') && (
          <div>
            <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Reference Date
            </label>
            <input
              type="date"
              value={targetDate}
              onChange={(e) => setTargetDate(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
            />
          </div>
        )}

        {reportType === 'employee' && (
          <div>
            <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Select Employee
            </label>
            <select
              value={selectedEmp}
              onChange={(e) => setSelectedEmp(Number(e.target.value))}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
            >
              {employees.map((e) => (
                <option key={e.employee_id} value={e.employee_id}>
                  {e.first_name} {e.last_name} ({e.employee_code})
                </option>
              ))}
            </select>
          </div>
        )}

        {reportType !== 'employee' && (
          <div>
            <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Department
            </label>
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
            >
              <option value="">All Departments</option>
              {departments.map((d) => (
                <option key={d.department_id} value={d.department_id}>
                  {d.department_name}
                </option>
              ))}
            </select>
          </div>
        )}

        {(reportType === 'employee' || reportType === 'department') && (
          <>
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                End Date
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
              />
            </div>
          </>
        )}
      </div>

      {/* Summary KPI Cards Row */}
      {summary && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Total Logs</span>
            <span className="text-xl font-bold text-slate-900 mt-0.5 block">{summary.total_records}</span>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 block">Present Rate</span>
            <span className="text-xl font-bold text-emerald-600 mt-0.5 block">{summary.attendance_rate}%</span>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 block">Late Arrivals</span>
            <span className="text-xl font-bold text-amber-600 mt-0.5 block">{summary.late_count}</span>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-[10px] font-bold uppercase tracking-wider text-rose-600 block">Absences</span>
            <span className="text-xl font-bold text-rose-600 mt-0.5 block">{summary.absent_count}</span>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 block">Total Hours</span>
            <span className="text-xl font-bold text-indigo-600 font-mono mt-0.5 block">{summary.total_working_hours}h</span>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 block">Avg Hours</span>
            <span className="text-xl font-bold text-blue-600 font-mono mt-0.5 block">{summary.average_working_hours}h</span>
          </div>
        </div>
      )}

      {/* Visual Chart */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm">
        <h2 className="text-sm font-bold text-slate-900 mb-3">Report Status Distribution</h2>
        <div className="h-56 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderRadius: '12px',
                  color: '#fff',
                  border: 'none',
                }}
              />
              <Bar dataKey="count" radius={[6, 6, 0, 0]} name="Count" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Records Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Report Data Set: <strong>{records.length}</strong> items</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Code</th>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Dept</th>
                <th className="px-4 py-3">In</th>
                <th className="px-4 py-3">Out</th>
                <th className="px-4 py-3">Hours</th>
                <th className="px-4 py-3">Late (m)</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={9} className="px-4 py-10 text-center text-slate-400">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto text-blue-600 mb-2" />
                    <span>Loading report...</span>
                  </td>
                </tr>
              ) : records.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-10 text-center text-slate-400">
                    No data available for the chosen report timeframe.
                  </td>
                </tr>
              ) : (
                records.map((r) => (
                  <tr key={r.attendance_id} className="hover:bg-slate-50/60">
                    <td className="px-4 py-3 font-mono text-slate-900 font-medium">{r.attendance_date}</td>
                    <td className="px-4 py-3 font-mono text-slate-500">{r.employee_code}</td>
                    <td className="px-4 py-3 font-bold text-slate-900">{r.employee_name}</td>
                    <td className="px-4 py-3 text-slate-600">{r.department_name}</td>
                    <td className="px-4 py-3 font-mono text-slate-700">
                      {r.check_in_time ? new Date(r.check_in_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-700">
                      {r.check_out_time ? new Date(r.check_out_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                    </td>
                    <td className="px-4 py-3 font-mono font-bold text-slate-800">
                      {r.total_working_hours ? `${r.total_working_hours}h` : '-'}
                    </td>
                    <td className="px-4 py-3 font-mono">
                      {r.late_minutes > 0 ? (
                        <span className="text-amber-600 font-bold">+{r.late_minutes}m</span>
                      ) : (
                        <span className="text-slate-400">0m</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          r.status === 'Present'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : r.status === 'Late'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : r.status === 'Half Day'
                            ? 'bg-orange-50 text-orange-700 border border-orange-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
