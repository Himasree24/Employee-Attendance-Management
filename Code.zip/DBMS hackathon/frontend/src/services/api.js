import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor: attach token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor: handle 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('access_token');
      localStorage.removeItem('user_info');
      if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// Authentication API
export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  getMe: () => api.get('/auth/me'),
  register: (data) => api.post('/auth/register', data),
};

// Employees API
export const employeesAPI = {
  getAll: (params) => api.get('/employees', { params }),
  getById: (id) => api.get(`/employees/${id}`),
  create: (data) => api.post('/employees', data),
  update: (id, data) => api.put(`/employees/${id}`, data),
  delete: (id) => api.delete(`/employees/${id}`),
};

// Departments API
export const departmentsAPI = {
  getAll: () => api.get('/departments'),
  create: (data) => api.post('/departments', data),
  update: (id, data) => api.put(`/departments/${id}`, data),
  delete: (id) => api.delete(`/departments/${id}`),
};

// Shifts API
export const shiftsAPI = {
  getAll: () => api.get('/shifts'),
  create: (data) => api.post('/shifts', data),
  update: (id, data) => api.put(`/shifts/${id}`, data),
  delete: (id) => api.delete(`/shifts/${id}`),
  assignShift: (data) => api.post('/shifts/assign', data),
  getAssignments: (params) => api.get('/shifts/assignments', { params }),
};

// Attendance API
export const attendanceAPI = {
  checkIn: (data) => api.post('/attendance/check-in', data),
  checkOut: (data) => api.post('/attendance/check-out', data),
  getToday: () => api.get('/attendance/today'),
  getPersonalHistory: (params) => api.get('/attendance/history', { params }),
  getAll: (params) => api.get('/attendance/all', { params }),
  getById: (id) => api.get(`/attendance/${id}`),
  update: (id, data) => api.put(`/attendance/${id}`, data),
};

// Reports API
export const reportsAPI = {
  getDaily: (params) => api.get('/reports/daily', { params }),
  getWeekly: (params) => api.get('/reports/weekly', { params }),
  getMonthly: (params) => api.get('/reports/monthly', { params }),
  getEmployee: (params) => api.get('/reports/employee', { params }),
  getDepartment: (params) => api.get('/reports/department', { params }),
  downloadCsvUrl: (params) => {
    const qs = new URLSearchParams(params).toString();
    return `${API_BASE_URL}/reports/export/csv?${qs}`;
  },
  downloadPdfUrl: (params) => {
    const qs = new URLSearchParams(params).toString();
    return `${API_BASE_URL}/reports/export/pdf?${qs}`;
  },
};

// Analytics API
export const analyticsAPI = {
  getDashboard: () => api.get('/analytics/dashboard'),
  getTrends: () => api.get('/analytics/attendance-trends'),
  getDeptStats: () => api.get('/analytics/department-attendance'),
};

// Anomaly Detection API
export const anomaliesAPI = {
  getAll: (params) => api.get('/anomalies', { params }),
  getById: (id) => api.get(`/anomalies/${id}`),
  resolve: (id, data) => api.put(`/anomalies/${id}/resolve`, data),
  triggerDetect: (params) => api.post('/anomalies/detect', null, { params }),
};

export default api;
