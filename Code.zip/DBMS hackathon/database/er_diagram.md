# Entity-Relationship (ER) Diagram & Schema Documentation

## Database Overview
The **Employee Attendance Management System** utilizes a normalized relational database design (`attendance_db`) in MySQL 8.0 with InnoDB engine, enforcing strict referential integrity through foreign keys, check constraints, cascading rules, and optimized B-Tree indexes.

---

## Mermaid ER Diagram

```mermaid
erDiagram
    DEPARTMENTS ||--o{ EMPLOYEES : "has"
    USERS |o--o| EMPLOYEES : "associated with"
    EMPLOYEES ||--o{ EMPLOYEE_SHIFTS : "assigned"
    SHIFTS ||--o{ EMPLOYEE_SHIFTS : "defines"
    EMPLOYEES ||--o{ ATTENDANCE : "logs"
    USERS |o--o{ ATTENDANCE : "audits/corrects"
    EMPLOYEES ||--o{ LEAVES : "requests"
    USERS |o--o{ LEAVES : "approves"
    EMPLOYEES ||--o{ ATTENDANCE_ALERTS : "triggers"
    ATTENDANCE |o--o{ ATTENDANCE_ALERTS : "associated with"

    DEPARTMENTS {
        int department_id PK
        varchar department_name UK
        text description
        timestamp created_at
    }

    EMPLOYEES {
        int employee_id PK
        varchar employee_code UK
        varchar first_name
        varchar last_name
        varchar email UK
        varchar phone
        int department_id FK
        varchar designation
        date date_of_joining
        enum employment_status
        timestamp created_at
    }

    USERS {
        int user_id PK
        varchar username UK
        varchar email UK
        varchar password_hash
        enum role
        int employee_id FK,UK
        boolean is_active
        timestamp created_at
    }

    SHIFTS {
        int shift_id PK
        varchar shift_name UK
        time start_time
        time end_time
        int grace_period_minutes
        varchar description
        boolean is_active
        boolean is_overnight
        timestamp created_at
    }

    EMPLOYEE_SHIFTS {
        int assignment_id PK
        int employee_id FK
        int shift_id FK
        date effective_from
        date effective_to
        timestamp created_at
    }

    ATTENDANCE {
        int attendance_id PK
        int employee_id FK
        date attendance_date
        datetime check_in_time
        datetime check_out_time
        enum status
        decimal total_working_hours
        int late_minutes
        int early_checkout_minutes
        varchar audit_remark
        int corrected_by FK
        timestamp created_at
    }

    LEAVES {
        int leave_id PK
        int employee_id FK
        date start_date
        date end_date
        enum leave_type
        text reason
        enum approval_status
        int approved_by FK
        timestamp created_at
    }

    ATTENDANCE_ALERTS {
        int alert_id PK
        int employee_id FK
        int attendance_id FK
        varchar alert_type
        text description
        enum severity
        timestamp detected_at
        boolean is_resolved
        text resolution_notes
        datetime resolved_at
    }
```

---

## Schema Architecture & Integrity Constraints

1. **Unique Constraints & Identity**:
   - `departments.department_name`: Unique department labels.
   - `employees.employee_code`: Unique employee badge/code (e.g., `EMP-1001`).
   - `employees.email`: Unique organizational email per employee.
   - `users.username` & `users.email`: Unique authentication credentials.
   - `attendance (employee_id, attendance_date)`: Unique compound constraint prevents duplicate attendance sessions for the same employee on the same date.

2. **Referential Integrity & Cascading**:
   - `employees.department_id -> departments.department_id`: Protected via `ON DELETE RESTRICT` to prevent accidental deletion of populated departments.
   - `attendance.employee_id -> employees.employee_id`: Cascading delete cleans attendance records if employee is expunged.
   - `users.employee_id -> employees.employee_id`: Nullable foreign key allows dedicated admin accounts without employee profiles; set to `NULL` upon employee deletion.
   - `attendance_alerts.attendance_id -> attendance.attendance_id`: Set to `NULL` if an underlying attendance row is removed.

3. **Performance Optimization (Indexes)**:
   - Composite index on `(employee_id, attendance_date)` for sub-millisecond retrieval of historical attendance and active shift detection.
   - Indexed `attendance_date` for daily and range-based report aggregations.
   - Indexed `is_resolved` and `severity` on `attendance_alerts` for high-throughput anomaly dashboard filtering.
