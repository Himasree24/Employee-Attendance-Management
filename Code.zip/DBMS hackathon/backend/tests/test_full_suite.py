import requests
import sys

BASE_URL = "http://127.0.0.1:8000/api"

def run_tests():
    print("=" * 60)
    print("RUNNING COMPLETE AUTOMATED INTEGRATION & REGRESSION TEST SUITE")
    print("=" * 60)

    # 1. Healthcheck
    res = requests.get(f"{BASE_URL}/health")
    assert res.status_code == 200, f"Health check failed: {res.text}"
    print("[PASS] Health Check Passed: 200 OK")

    # 2. Reject Invalid Credentials
    bad_login = requests.post(f"{BASE_URL}/auth/login", json={"username_or_email": "admin@company.com", "password": "WrongPassword!"})
    assert bad_login.status_code == 401, f"Expected 401 for bad password, got {bad_login.status_code}"
    print("[PASS] Invalid Login Correctly Rejected: 401 Unauthorized")

    # 3. Admin Authentication
    admin_login = requests.post(f"{BASE_URL}/auth/login", json={"username_or_email": "admin@company.com", "password": "Admin@123"})
    assert admin_login.status_code == 200, f"Admin login failed: {admin_login.text}"
    admin_data = admin_login.json()
    admin_token = admin_data["access_token"]
    admin_headers = {"Authorization": f"Bearer {admin_token}"}
    print(f"[PASS] Admin Login Verified: 200 OK (Role: {admin_data['role']})")

    # 4. Analytics Dashboard
    dash_res = requests.get(f"{BASE_URL}/analytics/dashboard", headers=admin_headers)
    assert dash_res.status_code == 200
    dash_json = dash_res.json()
    assert "stats" in dash_json and "trends" in dash_json and "department_stats" in dash_json
    print(f"[PASS] Analytics Dashboard API Verified: {dash_json['stats']['total_employees']} Employees, {dash_json['stats']['attendance_percentage']}% attendance")

    # 5. Department Management & Relational Delete Protection
    dept_res = requests.get(f"{BASE_URL}/departments", headers=admin_headers)
    assert dept_res.status_code == 200
    depts = dept_res.json()
    assert len(depts) >= 3
    print(f"[PASS] Department List Verified: {len(depts)} departments retrieved")

    # Try deleting a department with active employees (should be blocked with 400)
    eng_dept = next(d for d in depts if d["department_name"] == "Engineering")
    del_block_res = requests.delete(f"{BASE_URL}/departments/{eng_dept['department_id']}", headers=admin_headers)
    assert del_block_res.status_code == 400, f"Expected 400 when deleting populated department, got {del_block_res.status_code}"
    print("[PASS] Relational Constraint Enforced: Cannot delete department with active employees (400 Bad Request)")

    # Create & delete an empty temporary department
    new_dept_res = requests.post(f"{BASE_URL}/departments", json={"department_name": "QA Testing Temp Dept", "description": "Temp unit"}, headers=admin_headers)
    assert new_dept_res.status_code == 201
    temp_dept_id = new_dept_res.json()["department_id"]
    del_ok_res = requests.delete(f"{BASE_URL}/departments/{temp_dept_id}", headers=admin_headers)
    assert del_ok_res.status_code == 200
    print("[PASS] Department CRUD Verified: Created and safely deleted unpopulated department")

    # 6. Shifts Management & Overnight Shift Support
    shifts_res = requests.get(f"{BASE_URL}/shifts", headers=admin_headers)
    assert shifts_res.status_code == 200
    shifts = shifts_res.json()
    assert any(s["is_overnight"] for s in shifts), "Expected at least one overnight shift"
    print(f"[PASS] Shift System Verified: {len(shifts)} shifts including overnight support")

    # 7. Employee Management & Validation
    emp_res = requests.get(f"{BASE_URL}/employees", headers=admin_headers)
    assert emp_res.status_code == 200
    emps = emp_res.json()
    assert len(emps) >= 10
    print(f"[PASS] Employee Directory Verified: {len(emps)} employee records active")

    # Create new test employee
    new_emp_code = f"EMP-TEST-{len(emps) + 1}"
    new_emp_payload = {
        "employee_code": new_emp_code,
        "first_name": "Automated",
        "last_name": "Tester",
        "email": f"auto.tester.{len(emps) + 1}@company.com",
        "phone": "9998887776",
        "department_id": eng_dept["department_id"],
        "designation": "Automation Test Specialist",
        "date_of_joining": "2024-01-01",
        "initial_shift_id": shifts[0]["shift_id"],
        "create_user_account": True,
        "user_password": "User@123",
        "employment_status": "ACTIVE"
    }
    create_emp_res = requests.post(f"{BASE_URL}/employees", json=new_emp_payload, headers=admin_headers)
    assert create_emp_res.status_code == 201, f"Create employee failed: {create_emp_res.text}"
    created_emp = create_emp_res.json()
    print(f"[PASS] Employee Creation Verified: Created {created_emp['first_name']} {created_emp['last_name']} ({created_emp['employee_code']})")

    # 8. Employee Role Login & Authorization Boundaries
    emp_login = requests.post(f"{BASE_URL}/auth/login", json={"username_or_email": created_emp["email"], "password": "User@123"})
    assert emp_login.status_code == 200
    emp_data = emp_login.json()
    emp_token = emp_data["access_token"]
    emp_headers = {"Authorization": f"Bearer {emp_token}"}
    print(f"[PASS] Provisioned Employee Login Verified: 200 OK (Role: {emp_data['role']})")

    # Verify authorization boundary: Employee CANNOT access Admin endpoints
    forbidden_res = requests.get(f"{BASE_URL}/analytics/dashboard", headers=emp_headers)
    assert forbidden_res.status_code == 403, f"Expected 403 for employee on admin endpoint, got {forbidden_res.status_code}"
    print("[PASS] Role-Based Authorization Boundary Enforced: Employee access to Admin dashboard blocked with 403 Forbidden")

    # 9. Attendance Check-In / Check-Out Lifecycle
    # Check status before checkin
    today_status = requests.get(f"{BASE_URL}/attendance/today", headers=emp_headers).json()
    assert today_status["has_checked_in"] is False

    # Check In
    check_in_res = requests.post(f"{BASE_URL}/attendance/check-in", json={"notes": "Integration test arrival"}, headers=emp_headers)
    assert check_in_res.status_code == 200, f"Check in failed: {check_in_res.text}"
    check_in_data = check_in_res.json()
    assert check_in_data["check_in_time"] is not None
    print(f"[PASS] Check-In Verified: Status={check_in_data['status']}, Time={check_in_data['check_in_time']}")

    # Prevent Duplicate Check-In
    dup_check_in = requests.post(f"{BASE_URL}/attendance/check-in", json={}, headers=emp_headers)
    assert dup_check_in.status_code == 400
    print("[PASS] Duplicate Check-In Rejected: 400 Bad Request")

    # Check Out
    check_out_res = requests.post(f"{BASE_URL}/attendance/check-out", json={"notes": "Integration test departure"}, headers=emp_headers)
    assert check_out_res.status_code == 200
    check_out_data = check_out_res.json()
    assert check_out_data["check_out_time"] is not None
    print(f"[PASS] Check-Out Verified: Hours={check_out_data['total_working_hours']}h, Status={check_out_data['status']}")

    # Prevent Duplicate Check-Out
    dup_check_out = requests.post(f"{BASE_URL}/attendance/check-out", json={}, headers=emp_headers)
    assert dup_check_out.status_code == 400
    print("[PASS] Duplicate Check-Out Rejected: 400 Bad Request")

    # 10. Manual Attendance Correction With Audit Trail
    att_id = check_in_data["attendance_id"]
    audit_update_res = requests.put(
        f"{BASE_URL}/attendance/{att_id}",
        json={"status": "Present", "audit_remark": "Verified manager approval for integration test"},
        headers=admin_headers
    )
    assert audit_update_res.status_code == 200
    updated_att = audit_update_res.json()
    assert "admin" in updated_att["audit_remark"]
    print(f"[PASS] Audited Manual Attendance Correction Verified: {updated_att['audit_remark']}")

    # 11. Anomaly Detection & Resolution
    anom_res = requests.get(f"{BASE_URL}/anomalies", headers=admin_headers)
    assert anom_res.status_code == 200
    anomalies = anom_res.json()
    assert len(anomalies) > 0
    first_alert = anomalies[0]
    print(f"[PASS] Machine Learning Anomaly Detection Verified: {len(anomalies)} anomalies detected. First: [{first_alert['alert_type']}] for {first_alert['employee_name']}")

    # Resolve Alert
    resolve_res = requests.put(
        f"{BASE_URL}/anomalies/{first_alert['alert_id']}/resolve",
        json={"resolution_notes": "Reviewed with department manager; resolved in automated test"},
        headers=admin_headers
    )
    assert resolve_res.status_code == 200
    assert resolve_res.json()["is_resolved"] is True
    print(f"[PASS] Anomaly Alert Resolution Verified: Alert #{first_alert['alert_id']} marked as resolved")

    # 12. Reports & Exports
    daily_rep = requests.get(f"{BASE_URL}/reports/daily", headers=admin_headers)
    assert daily_rep.status_code == 200
    print(f"[PASS] Daily Report Verified: {daily_rep.json()['summary']['total_records']} records summarized")

    csv_rep = requests.get(f"{BASE_URL}/reports/export/csv", headers=admin_headers)
    assert csv_rep.status_code == 200 and "text/csv" in csv_rep.headers["content-type"]
    assert "Attendance ID,Employee Code" in csv_rep.text
    print(f"[PASS] CSV Export Stream Verified: {len(csv_rep.text)} bytes received")

    pdf_rep = requests.get(f"{BASE_URL}/reports/export/pdf", headers=admin_headers)
    assert pdf_rep.status_code == 200 and "application/pdf" in pdf_rep.headers["content-type"]
    assert pdf_rep.content.startswith(b"%PDF")
    print(f"[PASS] PDF Export Document Verified: {len(pdf_rep.content)} bytes generated with valid PDF header")

    print("\n" + "=" * 60)
    print("ALL 12 COMPREHENSIVE INTEGRATION TEST SUITES PASSED (100% SUCCESS)!")
    print("=" * 60)

if __name__ == "__main__":
    run_tests()
