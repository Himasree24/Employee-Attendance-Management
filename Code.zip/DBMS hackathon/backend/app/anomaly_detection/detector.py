import numpy as np
import pandas as pd
from datetime import datetime, timedelta, date
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models.attendance import Attendance, AttendanceStatus
from app.models.employee import Employee
from app.models.shift import Shift, EmployeeShift
from app.models.alert import AttendanceAlert, AlertSeverity
from app.core.config import settings

class AttendanceAnomalyDetector:
    def __init__(self, db: Session):
        self.db = db
        self.zscore_threshold = settings.ANOMALY_ZSCORE_THRESHOLD
        self.min_records = settings.MIN_RECORDS_FOR_ML
        self.late_threshold = settings.CHRONIC_LATE_COUNT_THRESHOLD
        self.early_threshold = settings.CHRONIC_EARLY_DEPARTURE_COUNT

    def run_detection_pipeline(self, target_employee_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Runs comprehensive statistical and machine learning anomaly detection.
        Detects:
        1. Chronic Late Arrivals
        2. Frequent Early Checkouts
        3. Extreme Working Hours Outliers (Z-score & Isolation Forest)
        4. Inconsistent Arrival Pattern (High Variance / Volatility)
        5. Consecutive Unexcused Absences
        6. Sudden Attendance Behavior Shifts
        """
        alerts_generated = []

        query = self.db.query(Employee).filter(Employee.employment_status == "ACTIVE")
        if target_employee_id:
            query = query.filter(Employee.employee_id == target_employee_id)
        employees = query.all()

        for emp in employees:
            emp_alerts = self._analyze_employee(emp)
            alerts_generated.extend(emp_alerts)

        self.db.commit()
        return alerts_generated

    def _analyze_employee(self, employee: Employee) -> List[Dict[str, Any]]:
        new_alerts = []
        lookback_days = 45
        cutoff_date = date.today() - timedelta(days=lookback_days)

        records = (
            self.db.query(Attendance)
            .filter(
                Attendance.employee_id == employee.employee_id,
                Attendance.attendance_date >= cutoff_date
            )
            .order_by(Attendance.attendance_date.asc())
            .all()
        )

        if not records:
            return new_alerts

        # Convert to Pandas DataFrame for robust vectorized analysis
        data = []
        for r in records:
            check_in_min = None
            if r.check_in_time:
                check_in_min = r.check_in_time.hour * 60 + r.check_in_time.minute

            data.append({
                "attendance_id": r.attendance_id,
                "date": r.attendance_date,
                "status": r.status.value if hasattr(r.status, "value") else str(r.status),
                "working_hours": float(r.total_working_hours) if r.total_working_hours is not None else 0.0,
                "late_minutes": r.late_minutes or 0,
                "early_checkout_minutes": r.early_checkout_minutes or 0,
                "check_in_minutes": check_in_min,
                "has_check_in": r.check_in_time is not None,
                "has_check_out": r.check_out_time is not None,
            })

        df = pd.DataFrame(data)

        # 1. Chronic Late Arrivals Detection (Past 14 days)
        recent_14d = df[df["date"] >= (date.today() - timedelta(days=14))]
        late_count = (recent_14d["late_minutes"] > 10).sum()
        if late_count >= self.late_threshold:
            avg_late = recent_14d[recent_14d["late_minutes"] > 10]["late_minutes"].mean()
            desc = (
                f"Employee arrived late {late_count} times in the last 14 days "
                f"(average delay of {avg_late:.1f} minutes). Exceeds policy threshold of {self.late_threshold}."
            )
            alert = self._create_alert_if_not_exists(
                employee_id=employee.employee_id,
                alert_type="CHRONIC_LATE_ARRIVAL",
                description=desc,
                severity=AlertSeverity.HIGH if late_count >= 5 else AlertSeverity.MEDIUM
            )
            if alert:
                new_alerts.append(alert)

        # 2. Frequent Early Checkouts Detection (Past 14 days)
        early_count = (recent_14d["early_checkout_minutes"] > 15).sum()
        if early_count >= self.early_threshold:
            avg_early = recent_14d[recent_14d["early_checkout_minutes"] > 15]["early_checkout_minutes"].mean()
            desc = (
                f"Employee checked out early {early_count} times in the last 14 days "
                f"(average early departure of {avg_early:.1f} minutes)."
            )
            alert = self._create_alert_if_not_exists(
                employee_id=employee.employee_id,
                alert_type="FREQUENT_EARLY_CHECKOUT",
                description=desc,
                severity=AlertSeverity.MEDIUM
            )
            if alert:
                new_alerts.append(alert)

        # 3. Consecutive Absenteeism Detection
        absent_records = df[df["status"] == "Absent"].sort_values("date")
        if len(absent_records) >= 3:
            # Check for consecutive calendar dates or working days
            consecutive = 1
            max_consecutive = 1
            dates = absent_records["date"].tolist()
            for i in range(1, len(dates)):
                if (dates[i] - dates[i-1]).days == 1:
                    consecutive += 1
                    if consecutive > max_consecutive:
                        max_consecutive = consecutive
                else:
                    consecutive = 1
            if max_consecutive >= 3:
                desc = (
                    f"Employee logged {max_consecutive} consecutive unexcused absent days. "
                    f"Immediate management follow-up recommended."
                )
                alert = self._create_alert_if_not_exists(
                    employee_id=employee.employee_id,
                    alert_type="CONSECUTIVE_ABSENCE",
                    description=desc,
                    severity=AlertSeverity.HIGH if max_consecutive >= 4 else AlertSeverity.MEDIUM
                )
                if alert:
                    new_alerts.append(alert)

        # 4. Statistical Working Hours & Check-in Volatility (Requires sufficient history)
        valid_worked = df[(df["working_hours"] > 0) & (df["has_check_in"])]
        if len(valid_worked) >= self.min_records:
            # A. Z-score on working hours
            hours = valid_worked["working_hours"].values
            mean_hrs = np.mean(hours)
            std_hrs = np.std(hours)

            if std_hrs > 0.3:
                z_scores = (hours - mean_hrs) / std_hrs
                outlier_indices = np.where(np.abs(z_scores) >= self.zscore_threshold)[0]

                for idx in outlier_indices:
                    row = valid_worked.iloc[idx]
                    actual_hrs = row["working_hours"]
                    z = z_scores[idx]
                    direction = "abnormally high" if z > 0 else "severely short"
                    desc = (
                        f"Unusual shift duration on {row['date']}: {actual_hrs:.2f} hrs "
                        f"(Employee average: {mean_hrs:.2f} hrs, StdDev: {std_hrs:.2f}, Z-Score: {z:.2f}). "
                        f"Classified as {direction} working session."
                    )
                    alert = self._create_alert_if_not_exists(
                        employee_id=employee.employee_id,
                        attendance_id=int(row["attendance_id"]),
                        alert_type="UNUSUAL_WORKING_HOURS",
                        description=desc,
                        severity=AlertSeverity.HIGH if abs(z) >= 3.0 else AlertSeverity.MEDIUM
                    )
                    if alert:
                        new_alerts.append(alert)

            # B. Check-in Consistency Index (Standard deviation of check-in minutes)
            checkin_minutes = valid_worked["check_in_minutes"].dropna().values
            if len(checkin_minutes) >= self.min_records:
                checkin_std = float(np.std(checkin_minutes))
                if checkin_std >= 45.0:  # Std dev >= 45 minutes signifies severe schedule instability
                    desc = (
                        f"High check-in volatility detected. Check-in standard deviation is {checkin_std:.1f} minutes "
                        f"(Threshold: 45 min). Demonstrates irregular attendance start times."
                    )
                    alert = self._create_alert_if_not_exists(
                        employee_id=employee.employee_id,
                        alert_type="INCONSISTENT_CHECKIN_TIMES",
                        description=desc,
                        severity=AlertSeverity.LOW
                    )
                    if alert:
                        new_alerts.append(alert)

            # C. Isolation Forest Multi-Variate Anomaly Detection (when >= 10 records available)
            if len(valid_worked) >= 10:
                try:
                    from sklearn.ensemble import IsolationForest
                    features = valid_worked[["working_hours", "late_minutes", "early_checkout_minutes"]].copy()
                    features["check_in_min"] = valid_worked["check_in_minutes"].fillna(540) # default 9am
                    
                    iso = IsolationForest(contamination=0.08, random_axis=42 if hasattr(IsolationForest, 'random_axis') else None, random_state=42)
                    preds = iso.fit_predict(features)
                    iso_outliers = np.where(preds == -1)[0]

                    for out_idx in iso_outliers:
                        out_row = valid_worked.iloc[out_idx]
                        desc = (
                            f"Multi-feature anomaly detected by Isolation Forest on {out_row['date']}: "
                            f"Hours={out_row['working_hours']}h, Late={out_row['late_minutes']}m, "
                            f"EarlyCheckout={out_row['early_checkout_minutes']}m."
                        )
                        alert = self._create_alert_if_not_exists(
                            employee_id=employee.employee_id,
                            attendance_id=int(out_row["attendance_id"]),
                            alert_type="MULTIVARIATE_PATTERN_ANOMALY",
                            description=desc,
                            severity=AlertSeverity.MEDIUM
                        )
                        if alert:
                            new_alerts.append(alert)
                except Exception as e:
                    # Gracefully skip Isolation Forest if any matrix singular issue
                    pass

        return new_alerts

    def _create_alert_if_not_exists(
        self,
        employee_id: int,
        alert_type: str,
        description: str,
        severity: AlertSeverity,
        attendance_id: Optional[int] = None
    ) -> Optional[Dict[str, Any]]:
        # Prevent duplicate unresolved alerts of same type for this employee
        existing = (
            self.db.query(AttendanceAlert)
            .filter(
                AttendanceAlert.employee_id == employee_id,
                AttendanceAlert.alert_type == alert_type,
                AttendanceAlert.is_resolved == False
            )
        )
        if attendance_id:
            existing = existing.filter(AttendanceAlert.attendance_id == attendance_id)
        
        # Don't duplicate if logged in the last 7 days
        seven_days_ago = datetime.utcnow() - timedelta(days=7)
        existing = existing.filter(AttendanceAlert.detected_at >= seven_days_ago).first()

        if existing:
            return None

        alert = AttendanceAlert(
            employee_id=employee_id,
            attendance_id=attendance_id,
            alert_type=alert_type,
            description=description,
            severity=severity,
            detected_at=datetime.utcnow(),
            is_resolved=False
        )
        self.db.add(alert)
        self.db.flush()

        return {
            "alert_id": alert.alert_id,
            "employee_id": alert.employee_id,
            "alert_type": alert.alert_type,
            "description": alert.description,
            "severity": alert.severity.value,
            "detected_at": alert.detected_at.isoformat()
        }
