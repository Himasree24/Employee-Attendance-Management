import json
from typing import List, Union
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator

class Settings(BaseSettings):
    DATABASE_URL: str = "mysql+pymysql://root:Bangtan%4011017@localhost:3306/attendance_db"
    SECRET_KEY: str = "e83c748c9df10a56bd12b84f3c7e99da54a8b7c210d3e5f6a9810234bc567def"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    ORGANIZATION_TIMEZONE: str = "Asia/Kolkata"
    GRACE_PERIOD_MINUTES_DEFAULT: int = 15
    ANOMALY_ZSCORE_THRESHOLD: float = 2.0
    MIN_RECORDS_FOR_ML: int = 5
    CHRONIC_LATE_COUNT_THRESHOLD: int = 3
    CHRONIC_EARLY_DEPARTURE_COUNT: int = 3
    CORS_ORIGINS: Union[str, List[str]] = ["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:3000"]

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def assemble_cors_origins(cls, v):
        if isinstance(v, str):
            if v.startswith("[") and v.endswith("]"):
                try:
                    return json.loads(v)
                except Exception:
                    pass
            return [i.strip() for i in v.split(",") if i.strip()]
        elif isinstance(v, list):
            return v
        return ["*"]

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

settings = Settings()
