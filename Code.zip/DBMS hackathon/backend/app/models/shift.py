from datetime import datetime
from sqlalchemy import Column, Integer, String, Time, Boolean, DateTime, Date, ForeignKey
from sqlalchemy.orm import relationship
from app.database.session import Base

class Shift(Base):
    __tablename__ = "shifts"

    shift_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    shift_name = Column(String(100), unique=True, nullable=False)
    start_time = Column(Time, nullable=False)
    end_time = Column(Time, nullable=False)
    grace_period_minutes = Column(Integer, default=15, nullable=False)
    description = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    is_overnight = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    employee_assignments = relationship("EmployeeShift", back_populates="shift", cascade="all, delete-orphan")


class EmployeeShift(Base):
    __tablename__ = "employee_shifts"

    assignment_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id", ondelete="CASCADE"), nullable=False, index=True)
    shift_id = Column(Integer, ForeignKey("shifts.shift_id", ondelete="CASCADE"), nullable=False, index=True)
    effective_from = Column(Date, nullable=False)
    effective_to = Column(Date, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    employee = relationship("Employee", back_populates="shift_assignments")
    shift = relationship("Shift", back_populates="employee_assignments")
