from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey, Enum as SqlEnum
from sqlalchemy.orm import relationship
import enum
from app.database.session import Base

class AlertSeverity(str, enum.Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"

class AttendanceAlert(Base):
    __tablename__ = "attendance_alerts"

    alert_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id", ondelete="CASCADE"), nullable=False, index=True)
    attendance_id = Column(Integer, ForeignKey("attendance.attendance_id", ondelete="SET NULL"), nullable=True, index=True)
    alert_type = Column(String(100), nullable=False)
    description = Column(Text, nullable=False)
    severity = Column(
        SqlEnum(AlertSeverity, values_callable=lambda obj: [e.value for e in obj]),
        default=AlertSeverity.MEDIUM,
        nullable=False,
        index=True
    )
    detected_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    is_resolved = Column(Boolean, default=False, nullable=False, index=True)
    resolution_notes = Column(Text, nullable=True)
    resolved_at = Column(DateTime, nullable=True)

    employee = relationship("Employee", back_populates="alerts")
    attendance = relationship("Attendance", back_populates="alerts")
