from datetime import datetime
from sqlalchemy import Column, Integer, String, Date, DateTime, Numeric, ForeignKey, Enum as SqlEnum, UniqueConstraint
from sqlalchemy.orm import relationship
import enum
from app.database.session import Base

class AttendanceStatus(str, enum.Enum):
    PRESENT = "Present"
    LATE = "Late"
    ABSENT = "Absent"
    HALF_DAY = "Half Day"
    ON_LEAVE = "On Leave"

class Attendance(Base):
    __tablename__ = "attendance"

    attendance_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id", ondelete="CASCADE"), nullable=False, index=True)
    attendance_date = Column(Date, nullable=False, index=True)
    check_in_time = Column(DateTime, nullable=True)
    check_out_time = Column(DateTime, nullable=True)
    status = Column(
        SqlEnum(AttendanceStatus, values_callable=lambda obj: [e.value for e in obj]),
        default=AttendanceStatus.ABSENT,
        nullable=False,
        index=True
    )
    total_working_hours = Column(Numeric(5, 2), default=0.00, nullable=False)
    late_minutes = Column(Integer, default=0, nullable=False)
    early_checkout_minutes = Column(Integer, default=0, nullable=False)
    audit_remark = Column(String(255), nullable=True)
    corrected_by = Column(Integer, ForeignKey("users.user_id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        UniqueConstraint("employee_id", "attendance_date", name="uq_emp_attendance_date"),
    )

    employee = relationship("Employee", back_populates="attendance_records")
    corrector = relationship("User", foreign_keys=[corrected_by])
    alerts = relationship("AttendanceAlert", back_populates="attendance", cascade="all, delete-orphan")
