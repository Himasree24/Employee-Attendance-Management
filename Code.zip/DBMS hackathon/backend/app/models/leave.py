from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Date, DateTime, ForeignKey, Enum as SqlEnum
from sqlalchemy.orm import relationship
import enum
from app.database.session import Base

class LeaveType(str, enum.Enum):
    SICK = "Sick"
    CASUAL = "Casual"
    EARNED = "Earned"
    UNPAID = "Unpaid"

class LeaveApprovalStatus(str, enum.Enum):
    PENDING = "Pending"
    APPROVED = "Approved"
    REJECTED = "Rejected"

class Leave(Base):
    __tablename__ = "leaves"

    leave_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id", ondelete="CASCADE"), nullable=False, index=True)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    leave_type = Column(
        SqlEnum(LeaveType, values_callable=lambda obj: [e.value for e in obj]),
        default=LeaveType.CASUAL,
        nullable=False
    )
    reason = Column(Text, nullable=True)
    approval_status = Column(
        SqlEnum(LeaveApprovalStatus, values_callable=lambda obj: [e.value for e in obj]),
        default=LeaveApprovalStatus.PENDING,
        nullable=False
    )
    approved_by = Column(Integer, ForeignKey("users.user_id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    employee = relationship("Employee", back_populates="leaves")
    approver = relationship("User", foreign_keys=[approved_by])
