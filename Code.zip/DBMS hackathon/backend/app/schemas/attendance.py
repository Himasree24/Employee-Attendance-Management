from datetime import date, datetime
from typing import Optional
from decimal import Decimal
from pydantic import BaseModel
from app.models.attendance import AttendanceStatus

class CheckInRequest(BaseModel):
    notes: Optional[str] = None

class CheckOutRequest(BaseModel):
    notes: Optional[str] = None

class AttendanceUpdate(BaseModel):
    status: Optional[AttendanceStatus] = None
    check_in_time: Optional[datetime] = None
    check_out_time: Optional[datetime] = None
    audit_remark: str

class AttendanceResponse(BaseModel):
    attendance_id: int
    employee_id: int
    employee_code: Optional[str] = None
    employee_name: Optional[str] = None
    department_name: Optional[str] = None
    attendance_date: date
    check_in_time: Optional[datetime] = None
    check_out_time: Optional[datetime] = None
    status: AttendanceStatus
    total_working_hours: Decimal
    late_minutes: int
    early_checkout_minutes: int
    audit_remark: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

class TodayAttendanceStatus(BaseModel):
    has_checked_in: bool
    has_checked_out: bool
    attendance_id: Optional[int] = None
    attendance_date: date
    check_in_time: Optional[datetime] = None
    check_out_time: Optional[datetime] = None
    status: Optional[str] = None
    total_working_hours: Decimal = Decimal("0.00")
    late_minutes: int = 0
    shift_name: Optional[str] = None
    shift_start: Optional[str] = None
    shift_end: Optional[str] = None
    grace_period_minutes: Optional[int] = 15
    is_overnight: bool = False
