from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, EmailStr, Field
from app.models.employee import EmploymentStatus

class EmployeeBase(BaseModel):
    employee_code: str = Field(..., min_length=2, max_length=50)
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    phone: Optional[str] = None
    department_id: int
    designation: str = Field(..., min_length=2, max_length=100)
    date_of_joining: date
    employment_status: EmploymentStatus = EmploymentStatus.ACTIVE

class EmployeeCreate(EmployeeBase):
    initial_shift_id: Optional[int] = None
    create_user_account: bool = True
    user_password: Optional[str] = "User@123"

class EmployeeUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    department_id: Optional[int] = None
    designation: Optional[str] = None
    date_of_joining: Optional[date] = None
    employment_status: Optional[EmploymentStatus] = None

class EmployeeResponse(EmployeeBase):
    employee_id: int
    created_at: datetime
    department_name: Optional[str] = None
    current_shift_name: Optional[str] = None
    current_shift_id: Optional[int] = None

    class Config:
        from_attributes = True

class EmployeeDetailResponse(EmployeeResponse):
    attendance_rate: Optional[float] = 0.0
    total_present_days: Optional[int] = 0
    total_late_days: Optional[int] = 0
