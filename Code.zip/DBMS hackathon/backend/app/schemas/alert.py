from datetime import datetime
from typing import Optional
from pydantic import BaseModel
from app.models.alert import AlertSeverity

class AlertCreate(BaseModel):
    employee_id: int
    attendance_id: Optional[int] = None
    alert_type: str
    description: str
    severity: AlertSeverity = AlertSeverity.MEDIUM

class AlertResolveRequest(BaseModel):
    resolution_notes: str

class AlertResponse(BaseModel):
    alert_id: int
    employee_id: int
    employee_code: Optional[str] = None
    employee_name: Optional[str] = None
    department_name: Optional[str] = None
    attendance_id: Optional[int] = None
    alert_type: str
    description: str
    severity: AlertSeverity
    detected_at: datetime
    is_resolved: bool
    resolution_notes: Optional[str] = None
    resolved_at: Optional[datetime] = None

    class Config:
        from_attributes = True
