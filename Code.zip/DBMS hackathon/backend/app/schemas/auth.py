from typing import Optional
from pydantic import BaseModel, EmailStr

class LoginRequest(BaseModel):
    username_or_email: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    username: str
    email: str
    employee_id: Optional[int] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None

class UserProfile(BaseModel):
    user_id: int
    username: str
    email: str
    role: str
    is_active: bool
    employee_id: Optional[int] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    department_name: Optional[str] = None
    designation: Optional[str] = None

    class Config:
        from_attributes = True

class RegisterRequest(BaseModel):
    username: str
    email: EmailStr
    password: str
    role: str = "EMPLOYEE"
    employee_id: Optional[int] = None
