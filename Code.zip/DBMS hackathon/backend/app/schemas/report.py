from datetime import date
from typing import List, Optional
from decimal import Decimal
from pydantic import BaseModel
from app.schemas.attendance import AttendanceResponse

class ReportSummary(BaseModel):
    total_records: int
    present_count: int
    late_count: int
    absent_count: int
    half_day_count: int
    on_leave_count: int
    attendance_rate: float
    total_working_hours: Decimal
    average_working_hours: float
    average_late_minutes: float

class DailyReportResponse(BaseModel):
    date: date
    summary: ReportSummary
    records: List[AttendanceResponse]

class RangeReportResponse(BaseModel):
    start_date: date
    end_date: date
    summary: ReportSummary
    records: List[AttendanceResponse]
