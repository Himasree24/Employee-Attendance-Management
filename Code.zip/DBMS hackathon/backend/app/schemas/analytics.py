from typing import List, Optional
from pydantic import BaseModel

class DashboardStats(BaseModel):
    total_employees: int
    present_today: int
    absent_today: int
    checked_in_now: int
    late_today: int
    attendance_percentage: float
    unresolved_alerts_count: int

class TrendItem(BaseModel):
    date: str
    present: int
    late: int
    absent: int
    total: int

class DepartmentStatItem(BaseModel):
    department_name: str
    total_employees: int
    present: int
    absent: int
    percentage: float

class StatusBreakdownItem(BaseModel):
    name: str
    value: int
    color: str

class AnalyticsDashboardResponse(BaseModel):
    stats: DashboardStats
    trends: List[TrendItem]
    department_stats: List[DepartmentStatItem]
    status_distribution: List[StatusBreakdownItem]
