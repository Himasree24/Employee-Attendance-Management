from datetime import time, date, datetime
from typing import Optional
from pydantic import BaseModel, Field

class ShiftBase(BaseModel):
    shift_name: str = Field(..., min_length=2, max_length=100)
    start_time: time
    end_time: time
    grace_period_minutes: int = Field(default=15, ge=0, le=120)
    description: Optional[str] = None
    is_active: bool = True
    is_overnight: bool = False

class ShiftCreate(ShiftBase):
    pass

class ShiftUpdate(BaseModel):
    shift_name: Optional[str] = None
    start_time: Optional[time] = None
    end_time: Optional[time] = None
    grace_period_minutes: Optional[int] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None
    is_overnight: Optional[bool] = None

class ShiftResponse(ShiftBase):
    shift_id: int
    created_at: datetime
    active_assignments_count: Optional[int] = 0

    class Config:
        from_attributes = True

class ShiftAssignmentCreate(BaseModel):
    employee_id: int
    shift_id: int
    effective_from: date
    effective_to: Optional[date] = None

class ShiftAssignmentResponse(BaseModel):
    assignment_id: int
    employee_id: int
    shift_id: int
    effective_from: date
    effective_to: Optional[date] = None
    created_at: datetime
    shift_name: Optional[str] = None
    start_time: Optional[time] = None
    end_time: Optional[time] = None

    class Config:
        from_attributes = True
