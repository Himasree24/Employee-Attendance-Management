from datetime import datetime, date, time, timedelta
from typing import Optional, Tuple
from decimal import Decimal
import pytz
from fastapi import HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from app.models.attendance import Attendance, AttendanceStatus
from app.models.shift import Shift, EmployeeShift
from app.models.employee import Employee
from app.schemas.attendance import TodayAttendanceStatus
from app.core.config import settings

def get_tz():
    return pytz.timezone(settings.ORGANIZATION_TIMEZONE)

def get_now_local() -> datetime:
    tz = get_tz()
    return datetime.now(tz)

def get_today_local() -> date:
    return get_now_local().date()

class AttendanceService:
    @staticmethod
    def get_assigned_shift(db: Session, employee_id: int, target_date: date) -> Optional[Shift]:
        """
        Retrieves the employee's assigned shift valid on target_date.
        Falls back to the first active organizational shift if unassigned.
        """
        assignment = (
            db.query(EmployeeShift)
            .filter(
                EmployeeShift.employee_id == employee_id,
                EmployeeShift.effective_from <= target_date,
                or_(EmployeeShift.effective_to.is_(None), EmployeeShift.effective_to >= target_date)
            )
            .order_by(EmployeeShift.effective_from.desc())
            .first()
        )
        if assignment and assignment.shift:
            return assignment.shift

        # Fallback to general morning shift or any active shift
        return db.query(Shift).filter(Shift.is_active == True).first()

    @staticmethod
    def calculate_shift_times(shift: Optional[Shift], target_date: date) -> Tuple[datetime, datetime, int, bool]:
        """
        Returns (shift_start_dt, shift_end_dt, grace_period_minutes, is_overnight)
        Handles overnight shifts spanning into the next calendar day.
        """
        if not shift:
            # Default standard 9 to 5
            start_dt = datetime.combine(target_date, time(9, 0, 0))
            end_dt = datetime.combine(target_date, time(17, 0, 0))
            return start_dt, end_dt, 15, False

        start_dt = datetime.combine(target_date, shift.start_time)
        is_overnight = shift.is_overnight or (shift.end_time < shift.start_time)
        if is_overnight:
            end_dt = datetime.combine(target_date + timedelta(days=1), shift.end_time)
        else:
            end_dt = datetime.combine(target_date, shift.end_time)

        grace = shift.grace_period_minutes if shift.grace_period_minutes is not None else 15
        return start_dt, end_dt, grace, is_overnight

    @classmethod
    def check_in(cls, db: Session, employee_id: int, notes: Optional[str] = None) -> Attendance:
        today = get_today_local()
        now = datetime.utcnow()  # Stored UTC / standard datetime

        # 1. Verify valid employee
        emp = db.query(Employee).filter(Employee.employee_id == employee_id).first()
        if not emp:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Employee record not found")

        # 2. Check if attendance already exists for today
        existing = db.query(Attendance).filter(
            Attendance.employee_id == employee_id,
            Attendance.attendance_date == today
        ).first()

        if existing and existing.check_in_time:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Attendance already recorded for today. Checked in at {existing.check_in_time.strftime('%H:%M:%S')}."
            )

        # 3. Retrieve assigned shift & calculate late minutes
        shift = cls.get_assigned_shift(db, employee_id, today)
        start_dt, end_dt, grace_minutes, _ = cls.calculate_shift_times(shift, today)

        # Local time for grace calculation
        local_now = get_now_local().replace(tzinfo=None)
        allowed_arrival = start_dt + timedelta(minutes=grace_minutes)

        late_minutes = 0
        if local_now > allowed_arrival:
            delta = local_now - start_dt
            late_minutes = int(delta.total_seconds() / 60)

        att_status = AttendanceStatus.LATE if late_minutes > 0 else AttendanceStatus.PRESENT

        if existing:
            existing.check_in_time = now
            existing.status = att_status
            existing.late_minutes = late_minutes
            if notes:
                existing.audit_remark = notes
            db.commit()
            db.refresh(existing)
            return existing
        else:
            record = Attendance(
                employee_id=employee_id,
                attendance_date=today,
                check_in_time=now,
                status=att_status,
                late_minutes=late_minutes,
                early_checkout_minutes=0,
                total_working_hours=Decimal("0.00"),
                audit_remark=notes
            )
            db.add(record)
            db.commit()
            db.refresh(record)
            return record

    @classmethod
    def check_out(cls, db: Session, employee_id: int, notes: Optional[str] = None) -> Attendance:
        today = get_today_local()
        now = datetime.utcnow()

        # Find today's record (or previous day if overnight shift)
        record = db.query(Attendance).filter(
            Attendance.employee_id == employee_id,
            Attendance.attendance_date == today
        ).first()

        if not record or not record.check_in_time:
            # Check if active check-in was logged yesterday (overnight shift)
            yesterday = today - timedelta(days=1)
            record_yesterday = db.query(Attendance).filter(
                Attendance.employee_id == employee_id,
                Attendance.attendance_date == yesterday,
                Attendance.check_in_time.isnot(None),
                Attendance.check_out_time.is_(None)
            ).first()

            if record_yesterday:
                record = record_yesterday
            else:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Cannot check out without checking in first."
                )

        if record.check_out_time is not None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Already checked out for this session at {record.check_out_time.strftime('%H:%M:%S')}."
            )

        if now <= record.check_in_time:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Check-out time cannot be earlier than or equal to check-in time."
            )

        # Calculate working hours
        duration_seconds = (now - record.check_in_time).total_seconds()
        working_hours = round(Decimal(duration_seconds / 3600.0), 2)

        # Early departure calculation
        shift = cls.get_assigned_shift(db, employee_id, record.attendance_date)
        _, end_dt, _, _ = cls.calculate_shift_times(shift, record.attendance_date)
        local_now = get_now_local().replace(tzinfo=None)

        early_minutes = 0
        if local_now < end_dt:
            early_delta = end_dt - local_now
            early_minutes = int(early_delta.total_seconds() / 60)

        # Determine if Half Day
        final_status = record.status
        if working_hours < Decimal("4.00"):
            final_status = AttendanceStatus.HALF_DAY

        record.check_out_time = now
        record.total_working_hours = working_hours
        record.early_checkout_minutes = early_minutes
        record.status = final_status
        if notes:
            existing_remark = record.audit_remark or ""
            record.audit_remark = f"{existing_remark} | CheckOut: {notes}".strip(" | ")

        db.commit()
        db.refresh(record)
        return record

    @classmethod
    def get_today_status(cls, db: Session, employee_id: int) -> TodayAttendanceStatus:
        today = get_today_local()
        record = db.query(Attendance).filter(
            Attendance.employee_id == employee_id,
            Attendance.attendance_date == today
        ).first()

        shift = cls.get_assigned_shift(db, employee_id, today)
        shift_name = shift.shift_name if shift else "Standard Shift"
        shift_start = str(shift.start_time) if shift else "09:00:00"
        shift_end = str(shift.end_time) if shift else "17:00:00"
        grace = shift.grace_period_minutes if shift else 15
        is_overnight = shift.is_overnight if shift else False

        if not record:
            return TodayAttendanceStatus(
                has_checked_in=False,
                has_checked_out=False,
                attendance_id=None,
                attendance_date=today,
                check_in_time=None,
                check_out_time=None,
                status=None,
                total_working_hours=Decimal("0.00"),
                late_minutes=0,
                shift_name=shift_name,
                shift_start=shift_start,
                shift_end=shift_end,
                grace_period_minutes=grace,
                is_overnight=is_overnight
            )

        return TodayAttendanceStatus(
            has_checked_in=record.check_in_time is not None,
            has_checked_out=record.check_out_time is not None,
            attendance_id=record.attendance_id,
            attendance_date=record.attendance_date,
            check_in_time=record.check_in_time,
            check_out_time=record.check_out_time,
            status=record.status.value if hasattr(record.status, "value") else str(record.status),
            total_working_hours=record.total_working_hours,
            late_minutes=record.late_minutes,
            shift_name=shift_name,
            shift_start=shift_start,
            shift_end=shift_end,
            grace_period_minutes=grace,
            is_overnight=is_overnight
        )
