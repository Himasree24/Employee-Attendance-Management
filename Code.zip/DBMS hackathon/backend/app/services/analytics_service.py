from datetime import date, timedelta
from typing import List, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models.employee import Employee, EmploymentStatus
from app.models.attendance import Attendance, AttendanceStatus
from app.models.department import Department
from app.models.alert import AttendanceAlert
from app.schemas.analytics import AnalyticsDashboardResponse, DashboardStats, TrendItem, DepartmentStatItem, StatusBreakdownItem
from app.services.attendance_service import get_today_local

class AnalyticsService:
    @classmethod
    def get_dashboard_data(cls, db: Session) -> AnalyticsDashboardResponse:
        today = get_today_local()

        # 1. Total active employees
        total_employees = db.query(Employee).filter(Employee.employment_status == EmploymentStatus.ACTIVE).count()

        # 2. Today's attendance records
        today_records = db.query(Attendance).filter(Attendance.attendance_date == today).all()

        present_today = sum(1 for r in today_records if r.status in [AttendanceStatus.PRESENT, AttendanceStatus.LATE])
        late_today = sum(1 for r in today_records if r.status == AttendanceStatus.LATE)
        checked_in_now = sum(1 for r in today_records if r.check_in_time is not None and r.check_out_time is None)
        
        # Absent count = active employees - logged present/late/halfday/onleave (or explicit absent records)
        explicit_absent = sum(1 for r in today_records if r.status == AttendanceStatus.ABSENT)
        unaccounted = max(0, total_employees - len(today_records))
        absent_today = explicit_absent + unaccounted

        att_pct = round((present_today / total_employees * 100.0), 1) if total_employees > 0 else 0.0

        # Unresolved alerts
        unresolved_alerts = db.query(AttendanceAlert).filter(AttendanceAlert.is_resolved == False).count()

        stats = DashboardStats(
            total_employees=total_employees,
            present_today=present_today,
            absent_today=absent_today,
            checked_in_now=checked_in_now,
            late_today=late_today,
            attendance_percentage=att_pct,
            unresolved_alerts_count=unresolved_alerts
        )

        # 3. 7-Day Attendance Trends
        trends: List[TrendItem] = []
        for i in range(6, -1, -1):
            day = today - timedelta(days=i)
            day_records = db.query(Attendance).filter(Attendance.attendance_date == day).all()
            p = sum(1 for r in day_records if r.status in [AttendanceStatus.PRESENT, AttendanceStatus.LATE])
            l = sum(1 for r in day_records if r.status == AttendanceStatus.LATE)
            a = sum(1 for r in day_records if r.status == AttendanceStatus.ABSENT)
            # if historical day, remaining active employees can be marked absent
            rem = max(0, total_employees - len(day_records))
            trends.append(TrendItem(
                date=day.strftime("%b %d"),
                present=p,
                late=l,
                absent=a + rem,
                total=total_employees
            ))

        # 4. Department Attendance Breakdown
        departments = db.query(Department).all()
        dept_stats: List[DepartmentStatItem] = []
        for d in departments:
            dept_emp_ids = [e.employee_id for e in d.employees if e.employment_status == EmploymentStatus.ACTIVE]
            dept_total = len(dept_emp_ids)
            if dept_total == 0:
                continue

            dept_today_present = (
                db.query(Attendance)
                .filter(
                    Attendance.employee_id.in_(dept_emp_ids),
                    Attendance.attendance_date == today,
                    Attendance.status.in_([AttendanceStatus.PRESENT, AttendanceStatus.LATE])
                )
                .count()
            )
            pct = round((dept_today_present / dept_total * 100.0), 1)
            dept_stats.append(DepartmentStatItem(
                department_name=d.department_name,
                total_employees=dept_total,
                present=dept_today_present,
                absent=dept_total - dept_today_present,
                percentage=pct
            ))

        # 5. Status Breakdown for Pie Chart
        half_day_today = sum(1 for r in today_records if r.status == AttendanceStatus.HALF_DAY)
        on_leave_today = sum(1 for r in today_records if r.status == AttendanceStatus.ON_LEAVE)

        status_dist = [
            StatusBreakdownItem(name="Present", value=max(0, present_today - late_today), color="#22c55e"),
            StatusBreakdownItem(name="Late", value=late_today, color="#eab308"),
            StatusBreakdownItem(name="Absent", value=absent_today, color="#ef4444"),
            StatusBreakdownItem(name="Half Day", value=half_day_today, color="#f97316"),
            StatusBreakdownItem(name="On Leave", value=on_leave_today, color="#3b82f6"),
        ]

        return AnalyticsDashboardResponse(
            stats=stats,
            trends=trends,
            department_stats=dept_stats,
            status_distribution=status_dist
        )
