import io
import csv
from datetime import date, datetime, timedelta
from typing import Optional, Dict, Any, List
from decimal import Decimal
from sqlalchemy.orm import Session
from sqlalchemy import func
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from app.models.attendance import Attendance, AttendanceStatus
from app.models.employee import Employee
from app.models.department import Department
from app.schemas.attendance import AttendanceResponse
from app.schemas.report import ReportSummary

class ReportService:
    @staticmethod
    def query_attendance(
        db: Session,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        employee_id: Optional[int] = None,
        department_id: Optional[int] = None,
        status_filter: Optional[str] = None
    ) -> List[Attendance]:
        query = db.query(Attendance).join(Employee)

        if start_date:
            query = query.filter(Attendance.attendance_date >= start_date)
        if end_date:
            query = query.filter(Attendance.attendance_date <= end_date)
        if employee_id:
            query = query.filter(Attendance.employee_id == employee_id)
        if department_id:
            query = query.filter(Employee.department_id == department_id)
        if status_filter and status_filter.upper() != "ALL":
            query = query.filter(Attendance.status == status_filter)

        return query.order_by(Attendance.attendance_date.desc(), Attendance.employee_id.asc()).all()

    @classmethod
    def calculate_summary(cls, records: List[Attendance]) -> ReportSummary:
        total = len(records)
        if total == 0:
            return ReportSummary(
                total_records=0,
                present_count=0,
                late_count=0,
                absent_count=0,
                half_day_count=0,
                on_leave_count=0,
                attendance_rate=0.0,
                total_working_hours=Decimal("0.00"),
                average_working_hours=0.0,
                average_late_minutes=0.0
            )

        present = sum(1 for r in records if r.status in [AttendanceStatus.PRESENT, AttendanceStatus.LATE])
        late = sum(1 for r in records if r.status == AttendanceStatus.LATE)
        absent = sum(1 for r in records if r.status == AttendanceStatus.ABSENT)
        half_day = sum(1 for r in records if r.status == AttendanceStatus.HALF_DAY)
        on_leave = sum(1 for r in records if r.status == AttendanceStatus.ON_LEAVE)

        total_hours = sum(Decimal(str(r.total_working_hours or 0.0)) for r in records)
        worked_count = sum(1 for r in records if (r.total_working_hours or 0) > 0)
        avg_hours = float(total_hours / worked_count) if worked_count > 0 else 0.0

        late_records = [r.late_minutes for r in records if (r.late_minutes or 0) > 0]
        avg_late = float(sum(late_records) / len(late_records)) if late_records else 0.0
        att_rate = round((present + half_day * 0.5) / total * 100.0, 1)

        return ReportSummary(
            total_records=total,
            present_count=present,
            late_count=late,
            absent_count=absent,
            half_day_count=half_day,
            on_leave_count=on_leave,
            attendance_rate=att_rate,
            total_working_hours=total_hours,
            average_working_hours=round(avg_hours, 2),
            average_late_minutes=round(avg_late, 1)
        )

    @classmethod
    def serialize_records(cls, records: List[Attendance]) -> List[AttendanceResponse]:
        output = []
        for r in records:
            emp = r.employee
            output.append(AttendanceResponse(
                attendance_id=r.attendance_id,
                employee_id=r.employee_id,
                employee_code=emp.employee_code if emp else "",
                employee_name=f"{emp.first_name} {emp.last_name}" if emp else "Unknown",
                department_name=emp.department.department_name if emp and emp.department else "N/A",
                attendance_date=r.attendance_date,
                check_in_time=r.check_in_time,
                check_out_time=r.check_out_time,
                status=r.status,
                total_working_hours=r.total_working_hours,
                late_minutes=r.late_minutes,
                early_checkout_minutes=r.early_checkout_minutes,
                audit_remark=r.audit_remark,
                created_at=r.created_at
            ))
        return output

    @classmethod
    def generate_csv(cls, records: List[Attendance]) -> str:
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            "Attendance ID",
            "Employee Code",
            "Employee Name",
            "Department",
            "Date",
            "Check-In",
            "Check-Out",
            "Status",
            "Working Hours",
            "Late (min)",
            "Early Departure (min)",
            "Audit Remark"
        ])

        for r in records:
            emp = r.employee
            writer.writerow([
                r.attendance_id,
                emp.employee_code if emp else "",
                f"{emp.first_name} {emp.last_name}" if emp else "",
                emp.department.department_name if emp and emp.department else "",
                str(r.attendance_date),
                r.check_in_time.strftime("%H:%M:%S") if r.check_in_time else "-",
                r.check_out_time.strftime("%H:%M:%S") if r.check_out_time else "-",
                r.status.value if hasattr(r.status, "value") else str(r.status),
                float(r.total_working_hours or 0.0),
                r.late_minutes or 0,
                r.early_checkout_minutes or 0,
                r.audit_remark or ""
            ])

        return output.getvalue()

    @classmethod
    def generate_pdf(cls, records: List[Attendance], title: str = "Attendance Report") -> bytes:
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)
        elements = []
        styles = getSampleStyleSheet()

        # Title
        title_style = ParagraphStyle(
            name="ReportTitle",
            parent=styles["Heading1"],
            fontSize=18,
            textColor=colors.HexColor("#0f172a"),
            spaceAfter=8
        )
        elements.append(Paragraph(title, title_style))
        elements.append(Paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Total Records: {len(records)}", styles["Normal"]))
        elements.append(Spacer(1, 15))

        # Table Data
        table_data = [[
            "Code", "Name", "Dept", "Date", "In", "Out", "Status", "Hours", "Late"
        ]]

        for r in records[:100]:  # Cap to first 100 for PDF performance
            emp = r.employee
            table_data.append([
                emp.employee_code if emp else "",
                f"{emp.first_name} {emp.last_name}"[:15] if emp else "",
                emp.department.department_name[:10] if emp and emp.department else "",
                str(r.attendance_date),
                r.check_in_time.strftime("%H:%M") if r.check_in_time else "-",
                r.check_out_time.strftime("%H:%M") if r.check_out_time else "-",
                r.status.value if hasattr(r.status, "value") else str(r.status),
                f"{float(r.total_working_hours or 0.0):.1f}h",
                f"{r.late_minutes}m" if r.late_minutes else "-"
            ])

        pdf_table = Table(table_data, colWidths=[60, 95, 65, 65, 45, 45, 55, 45, 45])
        pdf_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#0284c7")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor("#f8fafc")),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor("#f1f5f9")]),
        ]))

        elements.append(pdf_table)
        doc.build(elements)
        buffer.seek(0)
        return buffer.getvalue()
