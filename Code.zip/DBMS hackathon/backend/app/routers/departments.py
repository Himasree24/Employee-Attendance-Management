from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database.session import get_db
from app.core.deps import require_admin, get_current_user
from app.models.department import Department
from app.models.employee import Employee
from app.models.user import User
from app.schemas.department import DepartmentCreate, DepartmentUpdate, DepartmentResponse

router = APIRouter(prefix="/departments", tags=["Departments"])

@router.get("", response_model=List[DepartmentResponse])
def get_departments(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    departments = db.query(Department).all()
    results = []
    for d in departments:
        count = db.query(Employee).filter(Employee.department_id == d.department_id).count()
        results.append(DepartmentResponse(
            department_id=d.department_id,
            department_name=d.department_name,
            description=d.description,
            created_at=d.created_at,
            employee_count=count
        ))
    return results

@router.post("", response_model=DepartmentResponse, status_code=status.HTTP_201_CREATED)
def create_department(payload: DepartmentCreate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    existing = db.query(Department).filter(Department.department_name == payload.department_name).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Department with this name already exists")

    dept = Department(
        department_name=payload.department_name,
        description=payload.description
    )
    db.add(dept)
    db.commit()
    db.refresh(dept)
    return DepartmentResponse(
        department_id=dept.department_id,
        department_name=dept.department_name,
        description=dept.description,
        created_at=dept.created_at,
        employee_count=0
    )

@router.put("/{dept_id}", response_model=DepartmentResponse)
def update_department(dept_id: int, payload: DepartmentUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    dept = db.query(Department).filter(Department.department_id == dept_id).first()
    if not dept:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Department not found")

    if payload.department_name and payload.department_name != dept.department_name:
        existing = db.query(Department).filter(Department.department_name == payload.department_name).first()
        if existing:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Department name already taken")
        dept.department_name = payload.department_name

    if payload.description is not None:
        dept.description = payload.description

    db.commit()
    db.refresh(dept)
    count = db.query(Employee).filter(Employee.department_id == dept.department_id).count()
    return DepartmentResponse(
        department_id=dept.department_id,
        department_name=dept.department_name,
        description=dept.description,
        created_at=dept.created_at,
        employee_count=count
    )

@router.delete("/{dept_id}")
def delete_department(dept_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    dept = db.query(Department).filter(Department.department_id == dept_id).first()
    if not dept:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Department not found")

    emp_count = db.query(Employee).filter(Employee.department_id == dept_id).count()
    if emp_count > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cannot delete department. {emp_count} active employee(s) are assigned to it. Reassign employees first."
        )

    db.delete(dept)
    db.commit()
    return {"message": "Department successfully deleted"}
