from typing import List, Optional
from datetime import date
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.core.deps import get_current_user, require_admin
from app.models.user import User, UserRole
from app.models.attendance import Attendance
from app.models.employee import Employee
from app.schemas.attendance import (
    CheckInRequest,
    CheckOutRequest,
    AttendanceUpdate,
    AttendanceResponse,
    TodayAttendanceStatus
)
from app.services.attendance_service import AttendanceService, get_today_local
from app.services.report_service import ReportService

router = APIRouter(prefix="/attendance", tags=["Attendance"])

@router.post("/check-in", response_model=AttendanceResponse)
def employee_check_in(
    payload: CheckInRequest = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if not current_user.employee_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current user account is not associated with an employee profile."
        )

    notes = payload.notes if payload else None
    record = AttendanceService.check_in(db, current_user.employee_id, notes)
    serialized = ReportService.serialize_records([record])
    return serialized[0]

@router.post("/check-out", response_model=AttendanceResponse)
def employee_check_out(
    payload: CheckOutRequest = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if not current_user.employee_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current user account is not associated with an employee profile."
        )

    notes = payload.notes if payload else None
    record = AttendanceService.check_out(db, current_user.employee_id, notes)
    serialized = ReportService.serialize_records([record])
    return serialized[0]

@router.get("/today", response_model=TodayAttendanceStatus)
def get_today_status(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if not current_user.employee_id:
        # Default mock for admin without employee link
        return TodayAttendanceStatus(
            has_checked_in=False,
            has_checked_out=False,
            attendance_date=get_today_local(),
            shift_name="Administrator Mode"
        )
    return AttendanceService.get_today_status(db, current_user.employee_id)

@router.get("/history", response_model=List[AttendanceResponse])
def get_personal_attendance_history(
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if not current_user.employee_id:
        return []

    records = ReportService.query_attendance(
        db,
        start_date=start_date,
        end_date=end_date,
        employee_id=current_user.employee_id
    )
    return ReportService.serialize_records(records)

@router.get("/all", response_model=List[AttendanceResponse])
def get_all_attendance(
    target_date: Optional[date] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    employee_id: Optional[int] = None,
    department_id: Optional[int] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    if target_date:
        start_date = target_date
        end_date = target_date

    records = ReportService.query_attendance(
        db,
        start_date=start_date,
        end_date=end_date,
        employee_id=employee_id,
        department_id=department_id,
        status_filter=status
    )
    return ReportService.serialize_records(records)

@router.get("/{att_id}", response_model=AttendanceResponse)
def get_attendance_record(
    att_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    record = db.query(Attendance).filter(Attendance.attendance_id == att_id).first()
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Attendance record not found")

    if current_user.role != UserRole.ADMIN and current_user.employee_id != record.employee_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    return ReportService.serialize_records([record])[0]

@router.put("/{att_id}", response_model=AttendanceResponse)
def update_attendance_record(
    att_id: int,
    payload: AttendanceUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    record = db.query(Attendance).filter(Attendance.attendance_id == att_id).first()
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Attendance record not found")

    if not payload.audit_remark or not payload.audit_remark.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Audit remark is mandatory when manually modifying attendance records."
        )

    if payload.status is not None:
        record.status = payload.status

    if payload.check_in_time is not None:
        record.check_in_time = payload.check_in_time

    if payload.check_out_time is not None:
        if record.check_in_time and payload.check_out_time < record.check_in_time:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Check-out time cannot be earlier than check-in time."
            )
        record.check_out_time = payload.check_out_time
        duration = (record.check_out_time - record.check_in_time).total_seconds()
        record.total_working_hours = round(duration / 3600.0, 2)

    record.audit_remark = f"[Edited by {current_user.username}]: {payload.audit_remark}"
    record.corrected_by = current_user.user_id

    db.commit()
    db.refresh(record)
    return ReportService.serialize_records([record])[0]
