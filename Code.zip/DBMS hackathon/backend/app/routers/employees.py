from typing import List, Optional
from datetime import date
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import or_
from app.database.session import get_db
from app.core.deps import require_admin, get_current_user
from app.core.security import get_password_hash
from app.models.employee import Employee, EmploymentStatus
from app.models.department import Department
from app.models.shift import Shift, EmployeeShift
from app.models.user import User, UserRole
from app.models.attendance import Attendance, AttendanceStatus
from app.schemas.employee import EmployeeCreate, EmployeeUpdate, EmployeeResponse, EmployeeDetailResponse

router = APIRouter(prefix="/employees", tags=["Employees"])

@router.get("", response_model=List[EmployeeResponse])
def get_employees(
    search: Optional[str] = None,
    department_id: Optional[int] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(Employee).join(Department)

    if search:
        search_fmt = f"%{search}%"
        query = query.filter(
            or_(
                Employee.first_name.ilike(search_fmt),
                Employee.last_name.ilike(search_fmt),
                Employee.employee_code.ilike(search_fmt),
                Employee.email.ilike(search_fmt)
            )
        )

    if department_id:
        query = query.filter(Employee.department_id == department_id)

    if status and status.upper() != "ALL":
        query = query.filter(Employee.employment_status == status)

    employees = query.order_by(Employee.employee_id.asc()).all()

    today = date.today()
    results = []
    for emp in employees:
        # Get current shift
        curr_assignment = (
            db.query(EmployeeShift)
            .filter(
                EmployeeShift.employee_id == emp.employee_id,
                EmployeeShift.effective_from <= today,
                or_(EmployeeShift.effective_to.is_(None), EmployeeShift.effective_to >= today)
            )
            .order_by(EmployeeShift.effective_from.desc())
            .first()
        )

        shift_name = curr_assignment.shift.shift_name if curr_assignment and curr_assignment.shift else None
        shift_id = curr_assignment.shift_id if curr_assignment else None

        results.append(EmployeeResponse(
            employee_id=emp.employee_id,
            employee_code=emp.employee_code,
            first_name=emp.first_name,
            last_name=emp.last_name,
            email=emp.email,
            phone=emp.phone,
            department_id=emp.department_id,
            department_name=emp.department.department_name if emp.department else "",
            designation=emp.designation,
            date_of_joining=emp.date_of_joining,
            employment_status=emp.employment_status,
            current_shift_name=shift_name,
            current_shift_id=shift_id,
            created_at=emp.created_at
        ))
    return results

@router.post("", response_model=EmployeeResponse, status_code=status.HTTP_201_CREATED)
def create_employee(payload: EmployeeCreate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    # 1. Uniqueness validation
    if db.query(Employee).filter(Employee.employee_code == payload.employee_code).first():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Employee code already in use")

    if db.query(Employee).filter(Employee.email == payload.email).first():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered for another employee")

    dept = db.query(Department).filter(Department.department_id == payload.department_id).first()
    if not dept:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Specified Department does not exist")

    # 2. Create employee
    emp = Employee(
        employee_code=payload.employee_code,
        first_name=payload.first_name,
        last_name=payload.last_name,
        email=payload.email,
        phone=payload.phone,
        department_id=payload.department_id,
        designation=payload.designation,
        date_of_joining=payload.date_of_joining,
        employment_status=payload.employment_status
    )
    db.add(emp)
    db.flush()

    # 3. Create initial shift assignment if provided
    shift_name = None
    shift_id = None
    if payload.initial_shift_id:
        shift = db.query(Shift).filter(Shift.shift_id == payload.initial_shift_id).first()
        if shift:
            shift_assign = EmployeeShift(
                employee_id=emp.employee_id,
                shift_id=shift.shift_id,
                effective_from=payload.date_of_joining
            )
            db.add(shift_assign)
            shift_name = shift.shift_name
            shift_id = shift.shift_id

    # 4. Create user login account if requested
    if payload.create_user_account:
        username = payload.email.split("@")[0]
        # ensure unique username
        existing_u = db.query(User).filter(User.username == username).first()
        if existing_u:
            username = f"{payload.employee_code.lower().replace('-', '_')}"

        new_user = User(
            username=username,
            email=payload.email,
            password_hash=get_password_hash(payload.user_password or "User@123"),
            role=UserRole.EMPLOYEE,
            employee_id=emp.employee_id,
            is_active=True
        )
        db.add(new_user)

    db.commit()
    db.refresh(emp)

    return EmployeeResponse(
        employee_id=emp.employee_id,
        employee_code=emp.employee_code,
        first_name=emp.first_name,
        last_name=emp.last_name,
        email=emp.email,
        phone=emp.phone,
        department_id=emp.department_id,
        department_name=dept.department_name,
        designation=emp.designation,
        date_of_joining=emp.date_of_joining,
        employment_status=emp.employment_status,
        current_shift_name=shift_name,
        current_shift_id=shift_id,
        created_at=emp.created_at
    )

@router.get("/{emp_id}", response_model=EmployeeDetailResponse)
def get_employee_detail(emp_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    emp = db.query(Employee).filter(Employee.employee_id == emp_id).first()
    if not emp:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Employee not found")

    # If employee role, ensure can only see their own details
    if current_user.role != UserRole.ADMIN and current_user.employee_id != emp_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    today = date.today()
    curr_assignment = (
        db.query(EmployeeShift)
        .filter(
            EmployeeShift.employee_id == emp.employee_id,
            EmployeeShift.effective_from <= today,
            or_(EmployeeShift.effective_to.is_(None), EmployeeShift.effective_to >= today)
        )
        .order_by(EmployeeShift.effective_from.desc())
        .first()
    )

    # Attendance statistics
    records = db.query(Attendance).filter(Attendance.employee_id == emp_id).all()
    total_days = len(records)
    present_days = sum(1 for r in records if r.status in [AttendanceStatus.PRESENT, AttendanceStatus.LATE])
    late_days = sum(1 for r in records if r.status == AttendanceStatus.LATE)
    att_rate = round(present_days / total_days * 100.0, 1) if total_days > 0 else 0.0

    return EmployeeDetailResponse(
        employee_id=emp.employee_id,
        employee_code=emp.employee_code,
        first_name=emp.first_name,
        last_name=emp.last_name,
        email=emp.email,
        phone=emp.phone,
        department_id=emp.department_id,
        department_name=emp.department.department_name if emp.department else "",
        designation=emp.designation,
        date_of_joining=emp.date_of_joining,
        employment_status=emp.employment_status,
        current_shift_name=curr_assignment.shift.shift_name if curr_assignment and curr_assignment.shift else None,
        current_shift_id=curr_assignment.shift_id if curr_assignment else None,
        created_at=emp.created_at,
        attendance_rate=att_rate,
        total_present_days=present_days,
        total_late_days=late_days
    )

@router.put("/{emp_id}", response_model=EmployeeResponse)
def update_employee(emp_id: int, payload: EmployeeUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    emp = db.query(Employee).filter(Employee.employee_id == emp_id).first()
    if not emp:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Employee not found")

    if payload.email and payload.email != emp.email:
        existing = db.query(Employee).filter(Employee.email == payload.email).first()
        if existing:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already taken")
        emp.email = payload.email

    if payload.department_id:
        dept = db.query(Department).filter(Department.department_id == payload.department_id).first()
        if not dept:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Department does not exist")
        emp.department_id = payload.department_id

    if payload.first_name is not None:
        emp.first_name = payload.first_name
    if payload.last_name is not None:
        emp.last_name = payload.last_name
    if payload.phone is not None:
        emp.phone = payload.phone
    if payload.designation is not None:
        emp.designation = payload.designation
    if payload.date_of_joining is not None:
        emp.date_of_joining = payload.date_of_joining
    if payload.employment_status is not None:
        emp.employment_status = payload.employment_status

    db.commit()
    db.refresh(emp)

    return EmployeeResponse(
        employee_id=emp.employee_id,
        employee_code=emp.employee_code,
        first_name=emp.first_name,
        last_name=emp.last_name,
        email=emp.email,
        phone=emp.phone,
        department_id=emp.department_id,
        department_name=emp.department.department_name if emp.department else "",
        designation=emp.designation,
        date_of_joining=emp.date_of_joining,
        employment_status=emp.employment_status,
        created_at=emp.created_at
    )

@router.delete("/{emp_id}")
def delete_employee(emp_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    emp = db.query(Employee).filter(Employee.employee_id == emp_id).first()
    if not emp:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Employee not found")

    # Set status to INACTIVE or delete
    emp.employment_status = EmploymentStatus.INACTIVE
    db.commit()
    return {"message": "Employee deactivated successfully"}
