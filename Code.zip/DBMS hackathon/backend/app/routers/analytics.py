from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.core.deps import require_admin
from app.services.analytics_service import AnalyticsService
from app.schemas.analytics import AnalyticsDashboardResponse

router = APIRouter(prefix="/analytics", tags=["Analytics"])

@router.get("/dashboard", response_model=AnalyticsDashboardResponse)
def get_analytics_dashboard(db: Session = Depends(get_db), current_user = Depends(require_admin)):
    return AnalyticsService.get_dashboard_data(db)

@router.get("/attendance-trends")
def get_attendance_trends(db: Session = Depends(get_db), current_user = Depends(require_admin)):
    data = AnalyticsService.get_dashboard_data(db)
    return data.trends

@router.get("/department-attendance")
def get_department_attendance(db: Session = Depends(get_db), current_user = Depends(require_admin)):
    data = AnalyticsService.get_dashboard_data(db)
    return data.department_stats
