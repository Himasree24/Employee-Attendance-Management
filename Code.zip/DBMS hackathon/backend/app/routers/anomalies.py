from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.core.deps import require_admin
from app.models.alert import AttendanceAlert
from app.models.employee import Employee
from app.schemas.alert import AlertResponse, AlertResolveRequest
from app.anomaly_detection.detector import AttendanceAnomalyDetector

router = APIRouter(prefix="/anomalies", tags=["Anomaly Detection"])

@router.get("", response_model=List[AlertResponse])
def get_anomalies(
    is_resolved: Optional[bool] = None,
    employee_id: Optional[int] = None,
    severity: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    query = db.query(AttendanceAlert).join(Employee)

    if is_resolved is not None:
        query = query.filter(AttendanceAlert.is_resolved == is_resolved)
    if employee_id:
        query = query.filter(AttendanceAlert.employee_id == employee_id)
    if severity and severity.upper() != "ALL":
        query = query.filter(AttendanceAlert.severity == severity)

    alerts = query.order_by(AttendanceAlert.detected_at.desc()).all()

    results = []
    for a in alerts:
        emp = a.employee
        results.append(AlertResponse(
            alert_id=a.alert_id,
            employee_id=a.employee_id,
            employee_code=emp.employee_code if emp else None,
            employee_name=f"{emp.first_name} {emp.last_name}" if emp else None,
            department_name=emp.department.department_name if emp and emp.department else None,
            attendance_id=a.attendance_id,
            alert_type=a.alert_type,
            description=a.description,
            severity=a.severity,
            detected_at=a.detected_at,
            is_resolved=a.is_resolved,
            resolution_notes=a.resolution_notes,
            resolved_at=a.resolved_at
        ))
    return results

@router.get("/{alert_id}", response_model=AlertResponse)
def get_anomaly_detail(alert_id: int, db: Session = Depends(get_db), current_user = Depends(require_admin)):
    alert = db.query(AttendanceAlert).filter(AttendanceAlert.alert_id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alert not found")

    emp = alert.employee
    return AlertResponse(
        alert_id=alert.alert_id,
        employee_id=alert.employee_id,
        employee_code=emp.employee_code if emp else None,
        employee_name=f"{emp.first_name} {emp.last_name}" if emp else None,
        department_name=emp.department.department_name if emp and emp.department else None,
        attendance_id=alert.attendance_id,
        alert_type=alert.alert_type,
        description=alert.description,
        severity=alert.severity,
        detected_at=alert.detected_at,
        is_resolved=alert.is_resolved,
        resolution_notes=alert.resolution_notes,
        resolved_at=alert.resolved_at
    )

@router.put("/{alert_id}/resolve", response_model=AlertResponse)
def resolve_anomaly(
    alert_id: int,
    payload: AlertResolveRequest,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    alert = db.query(AttendanceAlert).filter(AttendanceAlert.alert_id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alert not found")

    alert.is_resolved = True
    alert.resolution_notes = f"[Resolved by {current_user.username}]: {payload.resolution_notes}"
    alert.resolved_at = datetime.utcnow()

    db.commit()
    db.refresh(alert)

    emp = alert.employee
    return AlertResponse(
        alert_id=alert.alert_id,
        employee_id=alert.employee_id,
        employee_code=emp.employee_code if emp else None,
        employee_name=f"{emp.first_name} {emp.last_name}" if emp else None,
        department_name=emp.department.department_name if emp and emp.department else None,
        attendance_id=alert.attendance_id,
        alert_type=alert.alert_type,
        description=alert.description,
        severity=alert.severity,
        detected_at=alert.detected_at,
        is_resolved=alert.is_resolved,
        resolution_notes=alert.resolution_notes,
        resolved_at=alert.resolved_at
    )

@router.post("/detect")
def trigger_anomaly_detection(
    employee_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    detector = AttendanceAnomalyDetector(db)
    generated = detector.run_detection_pipeline(target_employee_id=employee_id)
    return {
        "status": "success",
        "alerts_generated_count": len(generated),
        "details": generated
    }
