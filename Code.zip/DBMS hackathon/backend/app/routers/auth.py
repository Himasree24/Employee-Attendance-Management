from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import or_
from app.database.session import get_db
from app.core.security import verify_password, create_access_token, get_password_hash
from app.core.deps import get_current_user, require_admin
from app.models.user import User, UserRole
from app.schemas.auth import LoginRequest, TokenResponse, UserProfile, RegisterRequest

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = (
        db.query(User)
        .filter(
            or_(
                User.username == payload.username_or_email,
                User.email == payload.username_or_email
            )
        )
        .first()
    )

    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username/email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Account is disabled")

    token = create_access_token(
        subject=user.username,
        role=user.role.value if hasattr(user.role, "value") else str(user.role),
        employee_id=user.employee_id
    )

    first_name = user.employee.first_name if user.employee else ("Admin" if user.role == UserRole.ADMIN else user.username)
    last_name = user.employee.last_name if user.employee else ""

    return TokenResponse(
        access_token=token,
        token_type="bearer",
        role=user.role.value if hasattr(user.role, "value") else str(user.role),
        username=user.username,
        email=user.email,
        employee_id=user.employee_id,
        first_name=first_name,
        last_name=last_name
    )

@router.post("/register", response_model=UserProfile)
def register(payload: RegisterRequest, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    # Check duplicate username
    if db.query(User).filter(User.username == payload.username).first():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username already registered")
    if db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered")

    role_val = UserRole.ADMIN if payload.role.upper() == "ADMIN" else UserRole.EMPLOYEE
    new_user = User(
        username=payload.username,
        email=payload.email,
        password_hash=get_password_hash(payload.password),
        role=role_val,
        employee_id=payload.employee_id,
        is_active=True
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return UserProfile(
        user_id=new_user.user_id,
        username=new_user.username,
        email=new_user.email,
        role=new_user.role.value if hasattr(new_user.role, "value") else str(new_user.role),
        is_active=new_user.is_active,
        employee_id=new_user.employee_id,
        first_name=new_user.employee.first_name if new_user.employee else None,
        last_name=new_user.employee.last_name if new_user.employee else None,
        department_name=new_user.employee.department.department_name if new_user.employee and new_user.employee.department else None,
        designation=new_user.employee.designation if new_user.employee else None
    )

@router.get("/me", response_model=UserProfile)
def get_me(current_user: User = Depends(get_current_user)):
    emp = current_user.employee
    return UserProfile(
        user_id=current_user.user_id,
        username=current_user.username,
        email=current_user.email,
        role=current_user.role.value if hasattr(current_user.role, "value") else str(current_user.role),
        is_active=current_user.is_active,
        employee_id=current_user.employee_id,
        first_name=emp.first_name if emp else "Admin",
        last_name=emp.last_name if emp else "",
        department_name=emp.department.department_name if emp and emp.department else None,
        designation=emp.designation if emp else "System Administrator"
    )
