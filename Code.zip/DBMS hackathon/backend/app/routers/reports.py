from datetime import date, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.core.deps import require_admin
from app.services.report_service import ReportService
from app.schemas.report import DailyReportResponse, RangeReportResponse
from app.services.attendance_service import get_today_local

router = APIRouter(prefix="/reports", tags=["Reports"])

@router.get("/daily", response_model=DailyReportResponse)
def get_daily_report(
    report_date: Optional[date] = None,
    department_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    target_d = report_date or get_today_local()
    records = ReportService.query_attendance(
        db,
        start_date=target_d,
        end_date=target_d,
        department_id=department_id
    )
    summary = ReportService.calculate_summary(records)
    serialized = ReportService.serialize_records(records)
    return DailyReportResponse(
        date=target_d,
        summary=summary,
        records=serialized
    )

@router.get("/weekly", response_model=RangeReportResponse)
def get_weekly_report(
    start_date: Optional[date] = None,
    department_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    end_d = start_date or get_today_local()
    start_d = end_d - timedelta(days=6)
    records = ReportService.query_attendance(
        db,
        start_date=start_d,
        end_date=end_d,
        department_id=department_id
    )
    summary = ReportService.calculate_summary(records)
    serialized = ReportService.serialize_records(records)
    return RangeReportResponse(
        start_date=start_d,
        end_date=end_d,
        summary=summary,
        records=serialized
    )

@router.get("/monthly", response_model=RangeReportResponse)
def get_monthly_report(
    month: Optional[int] = None,
    year: Optional[int] = None,
    department_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    today = get_today_local()
    y = year or today.year
    m = month or today.month

    start_d = date(y, m, 1)
    if m == 12:
        end_d = date(y + 1, 1, 1) - timedelta(days=1)
    else:
        end_d = date(y, m + 1, 1) - timedelta(days=1)

    records = ReportService.query_attendance(
        db,
        start_date=start_d,
        end_date=end_d,
        department_id=department_id
    )
    summary = ReportService.calculate_summary(records)
    serialized = ReportService.serialize_records(records)
    return RangeReportResponse(
        start_date=start_d,
        end_date=end_d,
        summary=summary,
        records=serialized
    )

@router.get("/employee", response_model=RangeReportResponse)
def get_employee_report(
    employee_id: int,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    today = get_today_local()
    end_d = end_date or today
    start_d = start_date or (end_d - timedelta(days=30))

    records = ReportService.query_attendance(
        db,
        start_date=start_d,
        end_date=end_d,
        employee_id=employee_id
    )
    summary = ReportService.calculate_summary(records)
    serialized = ReportService.serialize_records(records)
    return RangeReportResponse(
        start_date=start_d,
        end_date=end_d,
        summary=summary,
        records=serialized
    )

@router.get("/department", response_model=RangeReportResponse)
def get_department_report(
    department_id: int,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    today = get_today_local()
    end_d = end_date or today
    start_d = start_date or (end_d - timedelta(days=30))

    records = ReportService.query_attendance(
        db,
        start_date=start_d,
        end_date=end_d,
        department_id=department_id
    )
    summary = ReportService.calculate_summary(records)
    serialized = ReportService.serialize_records(records)
    return RangeReportResponse(
        start_date=start_d,
        end_date=end_d,
        summary=summary,
        records=serialized
    )

@router.get("/export/csv")
def export_attendance_csv(
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    employee_id: Optional[int] = None,
    department_id: Optional[int] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    records = ReportService.query_attendance(
        db,
        start_date=start_date,
        end_date=end_date,
        employee_id=employee_id,
        department_id=department_id,
        status_filter=status
    )
    csv_data = ReportService.generate_csv(records)
    filename = f"attendance_report_{date.today().isoformat()}.csv"
    return Response(
        content=csv_data,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

@router.get("/export/pdf")
def export_attendance_pdf(
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    employee_id: Optional[int] = None,
    department_id: Optional[int] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(require_admin)
):
    records = ReportService.query_attendance(
        db,
        start_date=start_date,
        end_date=end_date,
        employee_id=employee_id,
        department_id=department_id,
        status_filter=status
    )
    pdf_bytes = ReportService.generate_pdf(records, title="Organization Attendance Report")
    filename = f"attendance_report_{date.today().isoformat()}.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )
