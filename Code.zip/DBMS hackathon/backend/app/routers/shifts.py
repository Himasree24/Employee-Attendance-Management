from typing import List
from datetime import date
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.core.deps import require_admin, get_current_user
from app.models.shift import Shift, EmployeeShift
from app.models.employee import Employee
from app.models.user import User
from app.schemas.shift import ShiftCreate, ShiftUpdate, ShiftResponse, ShiftAssignmentCreate, ShiftAssignmentResponse

router = APIRouter(prefix="/shifts", tags=["Shifts"])

@router.get("", response_model=List[ShiftResponse])
def get_shifts(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    shifts = db.query(Shift).all()
    results = []
    for s in shifts:
        active_assignments = (
            db.query(EmployeeShift)
            .filter(
                EmployeeShift.shift_id == s.shift_id,
                EmployeeShift.effective_from <= date.today(),
                (EmployeeShift.effective_to.is_(None) | (EmployeeShift.effective_to >= date.today()))
            )
            .count()
        )
        results.append(ShiftResponse(
            shift_id=s.shift_id,
            shift_name=s.shift_name,
            start_time=s.start_time,
            end_time=s.end_time,
            grace_period_minutes=s.grace_period_minutes,
            description=s.description,
            is_active=s.is_active,
            is_overnight=s.is_overnight,
            created_at=s.created_at,
            active_assignments_count=active_assignments
        ))
    return results

@router.post("", response_model=ShiftResponse, status_code=status.HTTP_201_CREATED)
def create_shift(payload: ShiftCreate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    existing = db.query(Shift).filter(Shift.shift_name == payload.shift_name).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Shift with this name already exists")

    # Automatically set is_overnight if end_time < start_time
    is_overnight = payload.is_overnight or (payload.end_time < payload.start_time)

    shift = Shift(
        shift_name=payload.shift_name,
        start_time=payload.start_time,
        end_time=payload.end_time,
        grace_period_minutes=payload.grace_period_minutes,
        description=payload.description,
        is_active=payload.is_active,
        is_overnight=is_overnight
    )
    db.add(shift)
    db.commit()
    db.refresh(shift)
    return ShiftResponse(
        shift_id=shift.shift_id,
        shift_name=shift.shift_name,
        start_time=shift.start_time,
        end_time=shift.end_time,
        grace_period_minutes=shift.grace_period_minutes,
        description=shift.description,
        is_active=shift.is_active,
        is_overnight=shift.is_overnight,
        created_at=shift.created_at,
        active_assignments_count=0
    )

@router.put("/{shift_id}", response_model=ShiftResponse)
def update_shift(shift_id: int, payload: ShiftUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    shift = db.query(Shift).filter(Shift.shift_id == shift_id).first()
    if not shift:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shift not found")

    if payload.shift_name and payload.shift_name != shift.shift_name:
        existing = db.query(Shift).filter(Shift.shift_name == payload.shift_name).first()
        if existing:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Shift name already taken")
        shift.shift_name = payload.shift_name

    if payload.start_time is not None:
        shift.start_time = payload.start_time
    if payload.end_time is not None:
        shift.end_time = payload.end_time
    if payload.grace_period_minutes is not None:
        shift.grace_period_minutes = payload.grace_period_minutes
    if payload.description is not None:
        shift.description = payload.description
    if payload.is_active is not None:
        shift.is_active = payload.is_active

    if payload.is_overnight is not None:
        shift.is_overnight = payload.is_overnight
    else:
        shift.is_overnight = (shift.end_time < shift.start_time)

    db.commit()
    db.refresh(shift)
    return ShiftResponse(
        shift_id=shift.shift_id,
        shift_name=shift.shift_name,
        start_time=shift.start_time,
        end_time=shift.end_time,
        grace_period_minutes=shift.grace_period_minutes,
        description=shift.description,
        is_active=shift.is_active,
        is_overnight=shift.is_overnight,
        created_at=shift.created_at,
        active_assignments_count=0
    )

@router.delete("/{shift_id}")
def delete_shift(shift_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    shift = db.query(Shift).filter(Shift.shift_id == shift_id).first()
    if not shift:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shift not found")

    # Check active assignments
    count = db.query(EmployeeShift).filter(EmployeeShift.shift_id == shift_id).count()
    if count > 0:
        # Instead of breaking shift history, soft deactivate if in use
        shift.is_active = False
        db.commit()
        return {"message": "Shift has historical assignments; deactivated instead of deleted."}

    db.delete(shift)
    db.commit()
    return {"message": "Shift permanently deleted"}

@router.post("/assign", response_model=ShiftAssignmentResponse)
def assign_shift(payload: ShiftAssignmentCreate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    emp = db.query(Employee).filter(Employee.employee_id == payload.employee_id).first()
    if not emp:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Employee not found")

    shift = db.query(Shift).filter(Shift.shift_id == payload.shift_id).first()
    if not shift:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shift not found")

    # Close previous active assignments
    active_assignments = (
        db.query(EmployeeShift)
        .filter(
            EmployeeShift.employee_id == payload.employee_id,
            EmployeeShift.effective_to.is_(None)
        )
        .all()
    )
    for a in active_assignments:
        a.effective_to = payload.effective_from

    assignment = EmployeeShift(
        employee_id=payload.employee_id,
        shift_id=payload.shift_id,
        effective_from=payload.effective_from,
        effective_to=payload.effective_to
    )
    db.add(assignment)
    db.commit()
    db.refresh(assignment)

    return ShiftAssignmentResponse(
        assignment_id=assignment.assignment_id,
        employee_id=assignment.employee_id,
        shift_id=assignment.shift_id,
        effective_from=assignment.effective_from,
        effective_to=assignment.effective_to,
        created_at=assignment.created_at,
        shift_name=shift.shift_name,
        start_time=shift.start_time,
        end_time=shift.end_time
    )

@router.get("/assignments", response_model=List[ShiftAssignmentResponse])
def get_assignments(employee_id: int = None, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    query = db.query(EmployeeShift).join(Shift)
    if employee_id:
        query = query.filter(EmployeeShift.employee_id == employee_id)
    records = query.order_by(EmployeeShift.effective_from.desc()).all()

    results = []
    for r in records:
        results.append(ShiftAssignmentResponse(
            assignment_id=r.assignment_id,
            employee_id=r.employee_id,
            shift_id=r.shift_id,
            effective_from=r.effective_from,
            effective_to=r.effective_to,
            created_at=r.created_at,
            shift_name=r.shift.shift_name if r.shift else None,
            start_time=r.shift.start_time if r.shift else None,
            end_time=r.shift.end_time if r.shift else None
        ))
    return results
