import sys
import os
from datetime import datetime, date, time, timedelta
from decimal import Decimal
import random

# Add parent directory to path so imports work when running directly
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from app.database.session import SessionLocal, engine, Base
from app.core.security import get_password_hash
from app.models.department import Department
from app.models.shift import Shift, EmployeeShift
from app.models.employee import Employee, EmploymentStatus
from app.models.user import User, UserRole
from app.models.attendance import Attendance, AttendanceStatus
from app.models.alert import AttendanceAlert
from app.anomaly_detection.detector import AttendanceAnomalyDetector

def seed_database():
    db = SessionLocal()
    print("Starting database seeding...")

    try:
        # Clear existing data in reverse order of foreign key dependency
        print("Cleaning existing records...")
        db.query(AttendanceAlert).delete()
        db.query(Attendance).delete()
        db.query(EmployeeShift).delete()
        db.query(User).delete()
        db.query(Employee).delete()
        db.query(Shift).delete()
        db.query(Department).delete()
        db.commit()

        # 1. SEED DEPARTMENTS (3 departments)
        print("Seeding departments...")
        dept_data = [
            {"department_name": "Engineering", "description": "Software development, QA, and cloud infrastructure."},
            {"department_name": "Human Resources", "description": "People operations, talent acquisition, and employee relations."},
            {"department_name": "Operations", "description": "Business workflows, customer support, and facilities management."}
        ]
        departments = {}
        for d in dept_data:
            dept = Department(**d)
            db.add(dept)
            db.flush()
            departments[d["department_name"]] = dept.department_id

        # 2. SEED SHIFTS (3 shifts, including overnight)
        print("Seeding shifts...")
        shift_data = [
            {
                "shift_name": "General Morning Shift",
                "start_time": time(9, 0, 0),
                "end_time": time(17, 0, 0),
                "grace_period_minutes": 15,
                "description": "Standard corporate daytime shift (09:00 - 17:00).",
                "is_active": True,
                "is_overnight": False
            },
            {
                "shift_name": "Mid-Day / Evening Shift",
                "start_time": time(13, 0, 0),
                "end_time": time(21, 0, 0),
                "grace_period_minutes": 15,
                "description": "Afternoon to evening operations shift (13:00 - 21:00).",
                "is_active": True,
                "is_overnight": False
            },
            {
                "shift_name": "Night Owl Shift",
                "start_time": time(21, 0, 0),
                "end_time": time(5, 0, 0),
                "grace_period_minutes": 15,
                "description": "Overnight infrastructure coverage (21:00 - 05:00 next day).",
                "is_active": True,
                "is_overnight": True
            }
        ]
        shifts = {}
        for s in shift_data:
            shift = Shift(**s)
            db.add(shift)
            db.flush()
            shifts[s["shift_name"]] = shift.shift_id

        # 3. SEED ADMIN ACCOUNT
        print("Seeding admin user account...")
        admin_user = User(
            username="admin",
            email="admin@company.com",
            password_hash=get_password_hash("Admin@123"),
            role=UserRole.ADMIN,
            employee_id=None,
            is_active=True
        )
        db.add(admin_user)
        db.flush()

        # 4. SEED 10 EMPLOYEES & CORRESPONDING USER ACCOUNTS
        print("Seeding 10 employees...")
        employees_specs = [
            ("EMP-1001", "John", "Doe", "john.doe@company.com", "9876543210", "Engineering", "Senior Software Engineer", date(2023, 1, 15), "General Morning Shift"),
            ("EMP-1002", "Jane", "Smith", "jane.smith@company.com", "9876543211", "Engineering", "Frontend Specialist", date(2023, 3, 1), "General Morning Shift"),
            ("EMP-1003", "Michael", "Johnson", "michael.j@company.com", "9876543212", "Engineering", "Backend Architect", date(2022, 6, 10), "General Morning Shift"),
            ("EMP-1004", "Robert", "Brown", "robert.b@company.com", "9876543213", "Operations", "Operations Analyst", date(2023, 7, 20), "General Morning Shift"), # Chronic Late
            ("EMP-1005", "Emily", "Davis", "emily.d@company.com", "9876543214", "Human Resources", "HR Generalist", date(2023, 2, 11), "General Morning Shift"), # Frequent Early Checkout
            ("EMP-1006", "David", "Miller", "david.m@company.com", "9876543215", "Operations", "Support Lead", date(2022, 11, 5), "Mid-Day / Evening Shift"),
            ("EMP-1007", "Sarah", "Wilson", "sarah.w@company.com", "9876543216", "Human Resources", "Talent Acquisition Manager", date(2021, 9, 1), "General Morning Shift"),
            ("EMP-1008", "Lisa", "Anderson", "lisa.a@company.com", "9876543217", "Engineering", "DevOps Engineer", date(2023, 8, 14), "Night Owl Shift"), # Volatile hours
            ("EMP-1009", "James", "Taylor", "james.t@company.com", "9876543218", "Operations", "Logistics Specialist", date(2023, 4, 18), "Mid-Day / Evening Shift"), # Absenteeism
            ("EMP-1010", "Amanda", "White", "amanda.w@company.com", "9876543219", "Engineering", "QA Automation Engineer", date(2023, 5, 25), "General Morning Shift"),
        ]

        created_employees = []
        for code, f_name, l_name, email, phone, dept_name, desig, doj, shift_name in employees_specs:
            emp = Employee(
                employee_code=code,
                first_name=f_name,
                last_name=l_name,
                email=email,
                phone=phone,
                department_id=departments[dept_name],
                designation=desig,
                date_of_joining=doj,
                employment_status=EmploymentStatus.ACTIVE
            )
            db.add(emp)
            db.flush()

            # Create User login for employee
            username = email.split("@")[0].replace(".", "_")
            user = User(
                username=username,
                email=email,
                password_hash=get_password_hash("User@123"),
                role=UserRole.EMPLOYEE,
                employee_id=emp.employee_id,
                is_active=True
            )
            db.add(user)

            # Assign shift
            shift_assign = EmployeeShift(
                employee_id=emp.employee_id,
                shift_id=shifts[shift_name],
                effective_from=doj
            )
            db.add(shift_assign)

            created_employees.append((emp, shift_name))

        db.commit()

        # 5. SEED REALISTIC ATTENDANCE RECORDS (Past 14 Days)
        print("Seeding realistic attendance history for pattern detection...")
        today = date.today()

        for emp, shift_name in created_employees:
            shift_id = shifts[shift_name]
            is_night = (shift_name == "Night Owl Shift")
            is_evening = (shift_name == "Mid-Day / Evening Shift")

            base_start_hour = 21 if is_night else (13 if is_evening else 9)
            base_end_hour = 5 if is_night else (21 if is_evening else 17)

            for day_offset in range(14, 0, -1):
                att_date = today - timedelta(days=day_offset)
                
                # Skip weekends (Saturday=5, Sunday=6) for corporate shifts
                if att_date.weekday() >= 5 and not is_night:
                    continue

                # Default Punctual Behavior
                check_in_h = base_start_hour
                check_in_m = random.randint(45, 58) if not is_night else random.randint(45, 58) # arrive slightly early
                late_min = 0
                early_min = 0
                status = AttendanceStatus.PRESENT

                # CASE 1: EMP-1004 (Robert Brown) -> Chronic Late
                if emp.employee_code == "EMP-1004":
                    if day_offset in [1, 2, 4, 7, 8, 10]:
                        late_min = random.randint(25, 50)
                        check_in_h = 9
                        check_in_m = late_min
                        status = AttendanceStatus.LATE
                
                # CASE 2: EMP-1005 (Emily Davis) -> Frequent Early Checkouts
                elif emp.employee_code == "EMP-1005":
                    if day_offset in [2, 3, 5, 8, 9]:
                        early_min = random.randint(40, 75)

                # CASE 3: EMP-1009 (James Taylor) -> Consecutive Absences
                elif emp.employee_code == "EMP-1009":
                    if day_offset in [3, 4, 5]:
                        # Log explicit unexcused absence
                        rec = Attendance(
                            employee_id=emp.employee_id,
                            attendance_date=att_date,
                            check_in_time=None,
                            check_out_time=None,
                            status=AttendanceStatus.ABSENT,
                            total_working_hours=Decimal("0.00"),
                            late_minutes=0,
                            early_checkout_minutes=0
                        )
                        db.add(rec)
                        continue

                # CASE 4: EMP-1008 (Lisa Anderson) -> Highly volatile hours
                elif emp.employee_code == "EMP-1008":
                    if day_offset in [2, 6, 11]:
                        # Severe short shift (half day / outlier)
                        worked_hours = Decimal(str(random.choice([3.2, 3.5, 12.5])))
                    else:
                        worked_hours = Decimal("8.00")

                check_in_dt = datetime.combine(att_date, time(check_in_h, check_in_m))
                
                # Check-out time calculation
                if emp.employee_code == "EMP-1008" and day_offset in [2, 6, 11]:
                    total_hrs = worked_hours
                    check_out_dt = check_in_dt + timedelta(hours=float(total_hrs))
                    if total_hrs < Decimal("4.00"):
                        status = AttendanceStatus.HALF_DAY
                else:
                    if is_night:
                        check_out_date = att_date + timedelta(days=1)
                        check_out_dt = datetime.combine(check_out_date, time(5, 5)) - timedelta(minutes=early_min)
                    else:
                        check_out_dt = datetime.combine(att_date, time(base_end_hour, 5)) - timedelta(minutes=early_min)

                    duration = (check_out_dt - check_in_dt).total_seconds()
                    total_hrs = round(Decimal(duration / 3600.0), 2)

                rec = Attendance(
                    employee_id=emp.employee_id,
                    attendance_date=att_date,
                    check_in_time=check_in_dt,
                    check_out_time=check_out_dt,
                    status=status,
                    total_working_hours=total_hrs,
                    late_minutes=late_min,
                    early_checkout_minutes=early_min
                )
                db.add(rec)

            # Seed TODAY's record for half the employees so live dashboard shows active workers
            if emp.employee_code in ["EMP-1001", "EMP-1002", "EMP-1004", "EMP-1006"]:
                check_in_time = datetime.combine(today, time(base_start_hour, 5))
                today_rec = Attendance(
                    employee_id=emp.employee_id,
                    attendance_date=today,
                    check_in_time=check_in_time,
                    check_out_time=None,  # Currently checked in!
                    status=AttendanceStatus.PRESENT,
                    total_working_hours=Decimal("0.00"),
                    late_minutes=0,
                    early_checkout_minutes=0
                )
                db.add(today_rec)

        db.commit()
        print("Attendance history successfully seeded!")

        # 6. RUN ANOMALY DETECTION PIPELINE
        print("Executing initial ML & Statistical Anomaly Detection Engine...")
        detector = AttendanceAnomalyDetector(db)
        alerts = detector.run_detection_pipeline()
        print(f"Anomaly Detection Complete! Generated {len(alerts)} alerts for human review.")

        print("\n==========================================")
        print("SEEDING COMPLETED SUCCESSFULLY!")
        print("Credentials for Testing:")
        print("  Admin:")
        print("    Email: admin@company.com  |  Password: Admin@123")
        print("  Employees (10 accounts available):")
        print("    EMP-1001: john.doe@company.com  |  Password: User@123")
        print("    EMP-1004: robert.b@company.com  |  Password: User@123 (Chronic Late)")
        print("    EMP-1005: emily.d@company.com   |  Password: User@123 (Early Departure)")
        print("==========================================\n")

    except Exception as e:
        db.rollback()
        print(f"Error during seeding: {e}")
        raise e
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
